<?php

require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    go('auth/login.php');
}

$login = trim($_POST['login'] ?? '');
$password = $_POST['password'] ?? '';

$s = $koneksi->prepare(
    'SELECT * FROM users WHERE username=? OR email=? LIMIT 1'
);

$s->bind_param(
    'ss',
    $login,
    $login
);

$s->execute();

$u = $s->get_result()->fetch_assoc();

if (
    !$u ||
    !password_verify($password, $u['password'])
) {
    flash(
        'error',
        'Username/email atau password tidak sesuai.'
    );

    go('auth/login.php');
}

$_SESSION['user_id'] = $u['id'];
$_SESSION['role'] = $u['role'];
$_SESSION['nama'] = $u['nama'];

go(
    $u['role'] === 'admin'
        ? 'admin/index.php'
        : 'user/index.php'
);
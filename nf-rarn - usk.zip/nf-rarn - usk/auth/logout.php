<?php

require_once __DIR__ . '/../config/koneksi.php';

session_unset();
session_destroy();

session_start();

flash(
    'success',
    'Anda sudah logout.'
);

go('index.php');
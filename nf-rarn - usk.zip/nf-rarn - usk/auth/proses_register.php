<?php

require_once __DIR__ . '/../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    go('auth/register.php');
}

$nama = trim($_POST['nama'] ?? '');
$email = filter_var(
    $_POST['email'] ?? '',
    FILTER_VALIDATE_EMAIL
);
$username = trim($_POST['username'] ?? '');
$pass = $_POST['password'] ?? '';

if (
    !$nama ||
    !$email ||
    !preg_match('/^[A-Za-z0-9_]{3,30}$/', $username) ||
    strlen($pass) < 6
) {
    flash(
        'error',
        'Data pendaftaran belum valid.'
    );

    go('auth/register.php');
}

$hash = password_hash(
    $pass,
    PASSWORD_DEFAULT
);

$s = $koneksi->prepare(
    "INSERT INTO users(nama,email,username,password,role)
     VALUES(?,?,?,?, 'user')"
);

$s->bind_param(
    'ssss',
    $nama,
    $email,
    $username,
    $hash
);

if (!$s->execute()) {

    flash(
        'error',
        'Email atau username sudah digunakan.'
    );

    go('auth/register.php');
}

flash(
    'success',
    'Registrasi berhasil. Silakan login.'
);

go('auth/login.php');
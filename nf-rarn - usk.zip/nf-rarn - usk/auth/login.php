<?php

require_once __DIR__ . '/../config/koneksi.php';

if (user()) {
    go($_SESSION['role'] === 'admin' ? 'admin/index.php' : 'user/index.php');
}

$title = 'Login — NF Rarn';

require __DIR__ . '/../partials/header.php';

?>

<section class="auth panel">

    <p class="eyebrow">
        SELAMAT DATANG
    </p>

    <h1>
        Masuk ke NF Rarn
    </h1>

    <form
        method="post"
        action="proses_login.php"
    >

        <div class="form-group">

            <label>
                Username atau Email
            </label>

            <input
                class="input"
                name="login"
                required
            >

        </div>

        <div class="form-group">

            <label>
                Password
            </label>

            <input
                class="input"
                type="password"
                name="password"
                required
            >

        </div>

        <button
            class="button"
            type="submit"
        >
            Login
        </button>

    </form>

    <p>
        Belum memiliki akun?
        <a href="register.php">
            <b>Daftar sekarang</b>
        </a>
    </p>

</section>

<?php require __DIR__ . '/../partials/footer.php'; ?>
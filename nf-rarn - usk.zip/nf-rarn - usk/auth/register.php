<?php

require_once __DIR__ . '/../config/koneksi.php';

$title = 'Daftar — NF Rarn';

require __DIR__ . '/../partials/header.php';

?>

<section class="auth panel">

    <p class="eyebrow">
        AKUN BARU
    </p>

    <h1>
        Buat akun pembaca
    </h1>

    <form
        method="post"
        action="proses_register.php"
    >

        <div class="form-group">

            <label>
                Nama lengkap
            </label>

            <input
                class="input"
                name="nama"
                required
            >

        </div>

        <div class="form-group">

            <label>
                Email
            </label>

            <input
                class="input"
                type="email"
                name="email"
                required
            >

        </div>

        <div class="form-group">

            <label>
                Username
            </label>

            <input
                class="input"
                name="username"
                required
                pattern="[A-Za-z0-9_]{3,30}"
            >

        </div>

        <div class="form-group">

            <label>
                Password (min. 6 karakter)
            </label>

            <input
                class="input"
                type="password"
                name="password"
                minlength="6"
                required
            >

        </div>

        <button class="button">
            Daftar
        </button>

    </form>

    <p>
        Sudah punya akun?

        <a href="login.php">
            <b>Login</b>
        </a>
    </p>

</section>

<?php require __DIR__ . '/../partials/footer.php'; ?>
<?php

require_once __DIR__ . '/config/koneksi.php';

$title = 'NF Rarn — Bookstore';

require __DIR__ . '/partials/header.php';

$cats = $koneksi->query(
    'SELECT * FROM categories ORDER BY nama_kategori'
);

$books = $koneksi->query(
    "SELECT b.*,c.nama_kategori
     FROM books b
     JOIN categories c ON c.id=b.category_id
     WHERE b.status='aktif'
     ORDER BY b.rating DESC,b.id DESC
     LIMIT 8"
);

?>

<section class="hero">

    <div>

        <p class="eyebrow">
            BOOKSTORE ONLINE
        </p>

        <h1>
            Temukan Cerita Favoritmu di <em>NF Rarn</em>
        </h1>

        <p>
            Jelajahi koleksi novel, komik, buku pengembangan diri,
            dan berbagai bacaan pilihan untuk menemani setiap
            perjalananmu.
        </p>

        <div class="row">

            <a
                class="button"
                href="<?= base_url('user/katalog.php') ?>"
            >
                Jelajahi Buku
            </a>

            <a
                class="button ghost"
                href="<?= base_url('user/katalog.php') ?>"
            >
                Lihat Katalog
            </a>

        </div>

    </div>

    <div class="book-stack">

        <span>
            Filosofi
            <br>
            <b>Teras</b>
        </span>

        <span>
            LAUT
            <br>
            <b>BERCERITA</b>
        </span>

        <span>
            Atomic
            <br>
            <b>Habits</b>
        </span>

    </div>

</section>

<section>

    <div class="section-head">

        <div>

            <p class="eyebrow">
                PILIHAN UNTUKMU
            </p>

            <h2>
                Jelajahi Berdasarkan Kategori
            </h2>

        </div>

        <a href="<?= base_url('user/katalog.php') ?>">
            Lihat semua →
        </a>

    </div>

    <div class="categories">

        <?php while ($c = $cats->fetch_assoc()): ?>

            <a
                href="<?= base_url('user/katalog.php?category=' . $c['id']) ?>"
            >

                <?= e($c['nama_kategori']) ?>

                <span>
                    →
                </span>

            </a>

        <?php endwhile ?>

    </div>

</section>

<section>

    <div class="section-head">

        <div>

            <p class="eyebrow">
                PILIHAN PEMBACA
            </p>

            <h2>
                Buku Populer
            </h2>

        </div>

        <a href="<?= base_url('user/katalog.php') ?>">
            Katalog lengkap →
        </a>

    </div>

    <div class="book-grid">

        <?php while ($b = $books->fetch_assoc()): ?>

            <?php
            include __DIR__ . '/partials/book-card.php';
            ?>

        <?php endwhile ?>

    </div>

</section>

<?php require __DIR__ . '/partials/footer.php'; ?>
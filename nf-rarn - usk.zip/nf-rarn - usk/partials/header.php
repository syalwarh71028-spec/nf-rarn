<?php
require_once __DIR__ . '/../config/koneksi.php';
$me = user();
?>
<!doctype html>
<html lang="id">
 
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <title><?= e($title ?? 'NF Rarn') ?></title>
 
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 
    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Playfair+Display:wght@600;700&display=swap"
        rel="stylesheet"
    >
 
    <!-- CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
 
<body>
 
    <!-- Navbar -->
    <header class="nav">
 
        <!-- Brand -->
        <a class="brand" href="<?= base_url() ?>">
            NF <i>Rarn</i>
        </a>
 
        <!-- Navigation -->
        <nav>
            <a href="<?= base_url() ?>">Home</a>
            <a href="<?= base_url('user/katalog.php') ?>">Katalog</a>
            <a href="<?= base_url('user/katalog.php#kategori') ?>">Kategori</a>
            <a href="<?= base_url('user/about.php') ?>">About Us</a>
            <a href="<?= base_url('user/contact.php') ?>">Contact</a>
        </nav>
 
        <!-- Navbar Actions -->
        <div class="nav-actions">
 
            <!-- Keranjang -->
            <a class="cart-link" href="<?= base_url('user/cart.php') ?>">
                Keranjang <b><?= cart_count() ?></b>
            </a>
 
            <?php if ($me && $me['role'] === 'user'): ?>
 
                <!-- User -->
                <a href="<?= base_url('user/pesanan.php') ?>">
                    Pesanan Saya
                </a>
 
            <?php elseif ($me && $me['role'] === 'admin'): ?>
 
                <!-- Admin -->
                <a href="<?= base_url('admin/index.php') ?>">
                    Dashboard Admin
                </a>
 
                <a href="<?= base_url('admin/pesanan.php') ?>">
                    Pesanan
                </a>
 
            <?php endif; ?>
 
            <!-- Login / Logout -->
            <?php if ($me): ?>
 
                <span class="hello">
                    Halo, <?= e($me['nama']) ?>
                </span>
 
                <a class="button small" href="<?= base_url('auth/logout.php') ?>">
                    Logout
                </a>
 
            <?php else: ?>
 
                <a class="button small" href="<?= base_url('auth/login.php') ?>">
                    Login
                </a>
 
            <?php endif; ?>
 
        </div>
    </header>
 
    <!-- Main Content -->
    <main>
 
        <!-- Success Message -->
        <?php if ($m = flash('success')): ?>
            <div class="notice success">
                <?= e($m) ?>
            </div>
        <?php endif; ?>
 
        <!-- Error Message -->
        <?php if ($m = flash('error')): ?>
            <div class="notice error">
                <?= e($m) ?>
            </div>
        <?php endif; ?>

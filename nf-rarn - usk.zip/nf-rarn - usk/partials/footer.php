</main>

<footer>

    <div>
        <strong>NF Rarn</strong>

        <p>
            Your favorite bookstore for every story,
            knowledge, and inspiration.
        </p>
    </div>

    <div>
        <a href="<?= base_url() ?>">
            Home
        </a>

        <a href="<?= base_url('user/katalog.php') ?>">
            Katalog
        </a>

        <a href="<?= base_url('user/about.php') ?>">
            About Us
        </a>

        <a href="<?= base_url('user/contact.php') ?>">
            Contact
        </a>
    </div>

    <small>
        © 2026 NF Rarn. All Rights Reserved.
    </small>

</footer>

<button
    id="top"
    title="Kembali ke atas"
>
    ↑
</button>

<script src="<?= base_url('assets/js/script.js') ?>"></script>

</body>

</html>
<article class="book-card">

    <a
        class="cover"
        href="<?= base_url('user/detail_buku.php?id=' . $b['id']) ?>"
    >

        <?php if ($b['cover']): ?>

            <img
                src="<?= base_url($b['cover']) ?>"
                alt="<?= e($b['judul']) ?>"
            >

        <?php else: ?>

            <span>
                NF Rarn
                <br>
                <b><?= e($b['judul']) ?></b>
            </span>

        <?php endif ?>

        <i>
            <?= $b['badge'] ? e($b['badge']) : 'Pilihan' ?>
        </i>

    </a>

    <div class="book-body">

        <p class="muted">
            <?= e($b['nama_kategori']) ?>
        </p>

        <h3>
            <?= e($b['judul']) ?>
        </h3>

        <p>
            <?= e($b['penulis']) ?>
        </p>

        <div class="rating">
            ★ <?= number_format((float)$b['rating'], 1) ?>
        </div>

        <strong>
            <?= rupiah($b['harga']) ?>
        </strong>

        <form
            method="post"
            action="<?= base_url('user/tambah_cart.php') ?>"
        >

            <input
                type="hidden"
                name="book_id"
                value="<?= $b['id'] ?>"
            >

            <button
                class="button small"
                <?= $b['stok'] < 1 ? 'disabled' : '' ?>
            >
                + Keranjang
            </button>

        </form>

    </div>

</article>
const topButton = document.getElementById('top');

if (topButton) {
    topButton.onclick = () => window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });

    window.onscroll = () => {
        topButton.style.display = scrollY > 350 ? 'block' : 'none';
    };
}

document.querySelectorAll('[data-preview]').forEach(i =>
    i.addEventListener('change', e => {
        const img = document.querySelector(i.dataset.preview);

        if (e.target.files[0] && img) {
            img.src = URL.createObjectURL(e.target.files[0]);
        }
    })
);
<?php header('Location: pesanan.php?detail='.(int)($_GET['id']??0)); exit;

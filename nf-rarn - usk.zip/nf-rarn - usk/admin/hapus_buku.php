<?php header('Location: buku.php?hapus='.(int)($_GET['id']??0)); exit;

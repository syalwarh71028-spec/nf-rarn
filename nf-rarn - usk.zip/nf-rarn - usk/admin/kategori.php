<?php

$title = 'Kategori';
require __DIR__ . '/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama = trim($_POST['nama'] ?? '');
    $id = (int)($_POST['id'] ?? 0);

    if (!$nama) {

        flash('error', 'Nama kategori wajib diisi.');

    } elseif ($id) {

        $s = $koneksi->prepare(
            'UPDATE categories SET nama_kategori=? WHERE id=?'
        );

        $s->bind_param('si', $nama, $id);
        $s->execute();

        flash('success', 'Kategori diperbarui.');

    } else {

        $s = $koneksi->prepare(
            'INSERT INTO categories(nama_kategori) VALUES(?)'
        );

        $s->bind_param('s', $nama);
        $s->execute();

        flash('success', 'Kategori ditambahkan.');
    }

    go('admin/kategori.php');
}

if (isset($_GET['hapus'])) {

    $id = (int)$_GET['hapus'];

    $s = $koneksi->prepare(
        'SELECT COUNT(*)n FROM books WHERE category_id=?'
    );

    $s->bind_param('i', $id);
    $s->execute();

    if ($s->get_result()->fetch_assoc()['n']) {

        flash(
            'error',
            'Kategori masih digunakan oleh buku.'
        );

    } else {

        $s = $koneksi->prepare(
            'DELETE FROM categories WHERE id=?'
        );

        $s->bind_param('i', $id);
        $s->execute();

        flash('success', 'Kategori dihapus.');
    }

    go('admin/kategori.php');
}

$edit = null;

if (isset($_GET['edit'])) {

    $s = $koneksi->prepare(
        'SELECT * FROM categories WHERE id=?'
    );

    $x = (int)$_GET['edit'];

    $s->bind_param('i', $x);
    $s->execute();

    $edit = $s->get_result()->fetch_assoc();
}

?>

<p class="eyebrow">
    MANAJEMEN DATA
</p>

<h1>
    Kategori Buku
</h1>

<section class="panel">

    <form
        method="post"
        class="row"
    >

        <input
            type="hidden"
            name="id"
            value="<?= $edit['id'] ?? '' ?>"
        >

        <input
            class="input"
            name="nama"
            value="<?= e($edit['nama_kategori'] ?? '') ?>"
            placeholder="Nama kategori"
            required
        >

        <button class="button">
            <?= $edit ? 'Simpan Perubahan' : 'Tambah Kategori' ?>
        </button>

        <?php if ($edit): ?>

            <a
                class="button ghost"
                href="kategori.php"
            >
                Batal
            </a>

        <?php endif ?>

    </form>

</section>

<section
    class="panel"
    style="margin-top:20px"
>

    <table>

        <tr>
            <th>No</th>
            <th>Nama Kategori</th>
            <th>Action</th>
        </tr>

        <?php

        $r = $koneksi->query(
            'SELECT * FROM categories ORDER BY nama_kategori'
        );

        $n = 1;

        while ($c = $r->fetch_assoc()):

        ?>

            <tr>

                <td>
                    <?= $n++ ?>
                </td>

                <td>
                    <?= e($c['nama_kategori']) ?>
                </td>

                <td>

                    <a href="?edit=<?= $c['id'] ?>">
                        Edit
                    </a>

                    ·

                    <a
                        href="?hapus=<?= $c['id'] ?>"
                        onclick="return confirm('Hapus kategori?')"
                    >
                        Hapus
                    </a>

                </td>

            </tr>

        <?php endwhile ?>

    </table>

</section>

<?php require __DIR__ . '/footer.php'; ?>
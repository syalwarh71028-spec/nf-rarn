<?php header('Location: buku.php'); exit;

<?php

$title = 'Data User';
require __DIR__ . '/header.php';

$r = $koneksi->query(
    "SELECT id,nama,email,username,tanggal_registrasi,role
     FROM users
     WHERE role='user'
     ORDER BY id DESC"
);

?>

<p class="eyebrow">
    MANAJEMEN AKUN
</p>

<h1>
    Data User
</h1>

<section class="panel">

    <table>

        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Username</th>
            <th>Tanggal Registrasi</th>
            <th>Role</th>
        </tr>

        <?php

        $n = 1;

        while ($u = $r->fetch_assoc()):

        ?>

            <tr>

                <td>
                    <?= $n++ ?>
                </td>

                <td>
                    <?= e($u['nama']) ?>
                </td>

                <td>
                    <?= e($u['email']) ?>
                </td>

                <td>
                    <?= e($u['username']) ?>
                </td>

                <td>
                    <?= e($u['tanggal_registrasi']) ?>
                </td>

                <td>
                    <?= e($u['role']) ?>
                </td>

            </tr>

        <?php endwhile ?>

    </table>

</section>

<?php require __DIR__ . '/footer.php'; ?>
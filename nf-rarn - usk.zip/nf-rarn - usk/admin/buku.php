
<?php

$title = 'Data Buku';
require __DIR__ . '/header.php';

$edit = null;

/*
|--------------------------------------------------------------------------
| EDIT BUKU
|--------------------------------------------------------------------------
*/

if (isset($_GET['edit'])) {

    $id = (int) $_GET['edit'];

    $s = $koneksi->prepare(
        'SELECT * FROM books WHERE id = ?'
    );

    $s->bind_param('i', $id);
    $s->execute();

    $edit = $s->get_result()->fetch_assoc();

    if (!$edit) {
        flash('error', 'Data buku tidak ditemukan.');
        go('admin/buku.php');
    }
}

/*
|--------------------------------------------------------------------------
| HAPUS BUKU PERMANEN
|--------------------------------------------------------------------------
*/

if (isset($_GET['hapus'])) {

    $id = (int) $_GET['hapus'];

    try {

        $s = $koneksi->prepare(
            'DELETE FROM books WHERE id = ?'
        );

        $s->bind_param('i', $id);
        $s->execute();

        if ($s->affected_rows > 0) {

            flash(
                'success',
                'Buku berhasil dihapus dari database.'
            );

        } else {

            flash(
                'error',
                'Buku tidak ditemukan atau sudah dihapus.'
            );

        }

    } catch (Throwable $e) {

        flash(
            'error',
            'Buku gagal dihapus. Data buku mungkin masih digunakan oleh transaksi.'
        );

    }

    go('admin/buku.php');
}

/*
|--------------------------------------------------------------------------
| TAMBAH DAN UPDATE BUKU
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        $id = (int) ($_POST['id'] ?? 0);

        $category = (int) ($_POST['category_id'] ?? 0);

        $judul = trim($_POST['judul'] ?? '');

        $penulis = trim($_POST['penulis'] ?? '');

        $penerbit = trim($_POST['penerbit'] ?? '');

        $tahun = (int) ($_POST['tahun'] ?? date('Y'));

        $harga = (float) ($_POST['harga'] ?? 0);

        $stok = (int) ($_POST['stok'] ?? 0);

        $desc = trim($_POST['deskripsi'] ?? '');

        $badge = trim($_POST['badge'] ?? '');

        /*
        |--------------------------------------------------------------------------
        | VALIDASI DATA
        |--------------------------------------------------------------------------
        */

        if (
            !$category ||
            !$judul ||
            !$penulis ||
            !$penerbit ||
            $harga < 0 ||
            $stok < 0
        ) {

            throw new Exception(
                'Data buku belum valid.'
            );

        }

        /*
        |--------------------------------------------------------------------------
        | UPLOAD COVER
        |--------------------------------------------------------------------------
        */

        $cover = upload_cover(
            $_FILES['cover'],
            $edit['cover'] ?? null
        );

        /*
        |--------------------------------------------------------------------------
        | UPDATE BUKU
        |--------------------------------------------------------------------------
        */

        if ($id > 0) {

            $s = $koneksi->prepare(
                'UPDATE books SET
                    category_id = ?,
                    judul = ?,
                    penulis = ?,
                    penerbit = ?,
                    tahun_terbit = ?,
                    harga = ?,
                    stok = ?,
                    deskripsi = ?,
                    cover = ?,
                    badge = ?
                WHERE id = ?'
            );

            $s->bind_param(
                'isssidisssi',
                $category,
                $judul,
                $penulis,
                $penerbit,
                $tahun,
                $harga,
                $stok,
                $desc,
                $cover,
                $badge,
                $id
            );

        }

        /*
        |--------------------------------------------------------------------------
        | INSERT BUKU BARU
        |--------------------------------------------------------------------------
        */

        else {

            $s = $koneksi->prepare(
                'INSERT INTO books (
                    category_id,
                    judul,
                    penulis,
                    penerbit,
                    tahun_terbit,
                    harga,
                    stok,
                    deskripsi,
                    cover,
                    badge
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );

            $s->bind_param(
                'isssidisss',
                $category,
                $judul,
                $penulis,
                $penerbit,
                $tahun,
                $harga,
                $stok,
                $desc,
                $cover,
                $badge
            );

        }

        $s->execute();

        /*
        |--------------------------------------------------------------------------
        | PESAN BERHASIL
        |--------------------------------------------------------------------------
        */

        if ($id > 0) {

            flash(
                'success',
                'Buku berhasil diperbarui.'
            );

        } else {

            flash(
                'success',
                'Buku berhasil ditambahkan!'
            );

        }

    } catch (Throwable $e) {

        flash(
            'error',
            $e->getMessage()
        );

    }

    go('admin/buku.php');
}

/*
|--------------------------------------------------------------------------
| DATA KATEGORI
|--------------------------------------------------------------------------
*/

$cats = $koneksi->query(
    'SELECT * FROM categories ORDER BY nama_kategori'
);

?>

<p class="eyebrow">
    MANAJEMEN KOLEKSI
</p>

<h1>Data Buku</h1>

<!-- ========================================================= -->
<!-- FORM TAMBAH / EDIT BUKU -->
<!-- ========================================================= -->

<section class="panel">

    <h2>
        <?= $edit ? 'Edit Buku' : 'Tambah Buku' ?>
    </h2>

    <form
        method="post"
        enctype="multipart/form-data"
    >

        <input
            type="hidden"
            name="id"
            value="<?= e($edit['id'] ?? '') ?>"
        >

        <div
            class="two-col"
            style="padding:0"
        >

            <!-- KOLOM KIRI -->

            <div>

                <div class="form-group">

                    <label>Judul Buku</label>

                    <input
                        class="input"
                        type="text"
                        name="judul"
                        value="<?= e($edit['judul'] ?? '') ?>"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Penulis</label>

                    <input
                        class="input"
                        type="text"
                        name="penulis"
                        value="<?= e($edit['penulis'] ?? '') ?>"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Penerbit</label>

                    <input
                        class="input"
                        type="text"
                        name="penerbit"
                        value="<?= e($edit['penerbit'] ?? '') ?>"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Tahun Terbit</label>

                    <input
                        class="input"
                        type="number"
                        name="tahun"
                        value="<?= e($edit['tahun_terbit'] ?? date('Y')) ?>"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Kategori</label>

                    <select
                        name="category_id"
                        required
                    >

                        <option value="">
                            Pilih Kategori
                        </option>

                        <?php while ($c = $cats->fetch_assoc()): ?>

                            <option
                                value="<?= $c['id'] ?>"
                                <?= ($edit['category_id'] ?? 0) == $c['id'] ? 'selected' : '' ?>
                            >

                                <?= e($c['nama_kategori']) ?>

                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>

            </div>

            <!-- KOLOM KANAN -->

            <div>

                <div class="form-group">

                    <label>Harga</label>

                    <input
                        class="input"
                        type="number"
                        name="harga"
                        min="0"
                        step="0.01"
                        value="<?= e($edit['harga'] ?? '') ?>"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Stok</label>

                    <input
                        class="input"
                        type="number"
                        name="stok"
                        min="0"
                        value="<?= e($edit['stok'] ?? '0') ?>"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Badge</label>

                    <select name="badge">

                        <option value="">
                            Tidak ada
                        </option>

                        <option
                            value="Best Seller"
                            <?= ($edit['badge'] ?? '') === 'Best Seller' ? 'selected' : '' ?>
                        >

                            Best Seller

                        </option>

                        <option
                            value="New"
                            <?= ($edit['badge'] ?? '') === 'New' ? 'selected' : '' ?>
                        >

                            New

                        </option>

                    </select>

                </div>

                <div class="form-group">

                    <label>
                        Cover (JPG/PNG/WEBP, maks. 2MB)
                    </label>

                    <input
                        class="input"
                        type="file"
                        name="cover"
                        accept="image/jpeg,image/png,image/webp"
                        data-preview="#preview"
                    >

                </div>

                <?php if (!empty($edit['cover'])): ?>

                    <img
                        id="preview"
                        class="thumb"
                        style="width:80px;height:105px"
                        src="<?= base_url($edit['cover']) ?>"
                    >

                <?php else: ?>

                    <img
                        id="preview"
                        class="thumb"
                        style="width:80px;height:105px;display:none"
                    >

                <?php endif; ?>

                <div class="form-group">

                    <label>Deskripsi</label>

                    <textarea
                        class="input"
                        name="deskripsi"
                        rows="4"
                    ><?= e($edit['deskripsi'] ?? '') ?></textarea>

                </div>

            </div>

        </div>

        <button
            type="submit"
            class="button"
        >

            Simpan Buku

        </button>

        <?php if ($edit): ?>

            <a
                class="button ghost"
                href="buku.php"
            >

                Batal

            </a>

        <?php endif; ?>

    </form>

</section>

<!-- ========================================================= -->
<!-- TABEL DATA BUKU -->
<!-- ========================================================= -->

<section
    class="panel"
    style="margin-top:20px"
>

    <h2>Daftar Buku</h2>

    <table>

        <thead>

            <tr>

                <th>Cover</th>

                <th>Judul</th>

                <th>Kategori</th>

                <th>Harga</th>

                <th>Stok</th>

                <th>Status</th>

                <th>Action</th>

            </tr>

        </thead>

        <tbody>

            <?php

            $r = $koneksi->query(
                'SELECT
                    b.*,
                    c.nama_kategori
                FROM books b
                JOIN categories c
                    ON c.id = b.category_id
                ORDER BY b.id DESC'
            );

            ?>

            <?php if ($r->num_rows > 0): ?>

                <?php while ($b = $r->fetch_assoc()): ?>

                    <tr>

                        <!-- COVER -->

                        <td>

                            <?php if (!empty($b['cover'])): ?>

                                <img
                                    class="thumb"
                                    src="<?= base_url($b['cover']) ?>"
                                    alt="<?= e($b['judul']) ?>"
                                >

                            <?php endif; ?>

                        </td>

                        <!-- JUDUL -->

                        <td>

                            <?= e($b['judul']) ?>

                        </td>

                        <!-- KATEGORI -->

                        <td>

                            <?= e($b['nama_kategori']) ?>

                        </td>

                        <!-- HARGA -->

                        <td>

                            <?= rupiah($b['harga']) ?>

                        </td>

                        <!-- STOK -->

                        <td>

                            <?= (int) $b['stok'] ?>

                        </td>

                        <!-- STATUS -->

                        <td>

                            <?= e($b['status']) ?>

                        </td>

                        <!-- ACTION -->

                        <td>

                            <a
                                href="?edit=<?= (int) $b['id'] ?>"
                            >

                                Edit

                            </a>

                            ·

                            <a
                                href="?hapus=<?= (int) $b['id'] ?>"
                                onclick="return confirm('Apakah kamu yakin ingin menghapus buku ini secara permanen?')"
                                style="color:#dc2626"
                            >

                                Hapus Buku

                            </a>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td colspan="7">

                        Belum ada data buku.

                    </td>

                </tr>

            <?php endif; ?>

        </tbody>

    </table>

</section>

<?php require __DIR__ . '/footer.php'; ?>

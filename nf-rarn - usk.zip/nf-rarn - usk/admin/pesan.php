<?php

$title = 'Pesan User';
require_once __DIR__ . '/../config/koneksi.php';
require_admin();
ensure_message_reply_columns();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $balasan = trim($_POST['balasan_admin'] ?? '');
    if ($id < 1 || $balasan === '') {
        flash('error', 'Balasan tidak boleh kosong.');
    } else {
        $s = $koneksi->prepare("UPDATE messages SET balasan_admin=?, tanggal_balasan=NOW(), status='Dibalas' WHERE id=?");
        $s->bind_param('si', $balasan, $id);
        $s->execute();
        flash('success', 'Balasan berhasil dikirim ke user.');
    }
    go('admin/pesan.php');
}

require __DIR__ . '/header.php';

if (isset($_GET['read'])) {

    $id = (int)$_GET['read'];

    $s = $koneksi->prepare(
        "UPDATE messages SET status='Dibaca' WHERE id=?"
    );

    $s->bind_param('i', $id);
    $s->execute();
}

$r = $koneksi->query(
    'SELECT * FROM messages ORDER BY id DESC'
);

?>

<p class="eyebrow">
    INBOX
</p>

<h1>
    Pesan User
</h1>

<section class="panel">

    <table>

        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Subject</th>
            <th>Pesan</th>
            <th>Balasan Admin</th>
            <th>Tanggal</th>
            <th>Status</th>
        </tr>

        <?php

        $n = 1;

        while ($m = $r->fetch_assoc()):

        ?>

            <tr>

                <td>
                    <?= $n++ ?>
                </td>

                <td>
                    <?= e($m['nama']) ?>
                </td>

                <td>
                    <?= e($m['email']) ?>
                </td>

                <td>
                    <?= e($m['subject']) ?>
                </td>

                <td>
                    <?= e($m['pesan']) ?>
                </td>

                <td>
                    <?php if (!empty($m['balasan_admin'])): ?>
                        <p><?= nl2br(e($m['balasan_admin'])) ?></p>
                    <?php endif; ?>
                    <form method="post" class="form-group">
                        <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                        <textarea name="balasan_admin" rows="3" required placeholder="Tulis balasan admin"><?= e($m['balasan_admin'] ?? '') ?></textarea>
                        <button class="button small" type="submit">Kirim Balasan</button>
                    </form>
                </td>

                <td>
                    <?= e($m['tanggal']) ?>
                </td>

                <td>

                    <a href="?read=<?= $m['id'] ?>">
                        <?= e($m['status']) ?>
                    </a>

                </td>

            </tr>

        <?php endwhile ?>

    </table>

</section>

<?php require __DIR__ . '/footer.php'; ?>

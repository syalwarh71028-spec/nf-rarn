<?php header('Location: buku.php?edit='.(int)($_GET['id']??0)); exit;

<?php

$title = 'Pesanan';
require __DIR__ . '/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = (int)$_POST['id'];
    $pay = $_POST['status_pembayaran'];
    $order = $_POST['status_pesanan'];

    $pays = [
        'Belum Dibayar',
        'Menunggu Konfirmasi',
        'Lunas',
        'Gagal'
    ];

    $orders = [
        'Menunggu Pembayaran',
        'Diproses',
        'Dikemas',
        'Dikirim',
        'Selesai',
        'Dibatalkan'
    ];

    if (
        in_array($pay, $pays, true) &&
        in_array($order, $orders, true)
    ) {

        $s = $koneksi->prepare(
            'UPDATE orders SET status_pembayaran=?,status_pesanan=? WHERE id=?'
        );

        $s->bind_param(
            'ssi',
            $pay,
            $order,
            $id
        );

        $s->execute();

        flash(
            'success',
            'Status pesanan diperbarui.'
        );
    }

    go(
        'admin/pesanan.php' .
        (isset($_GET['detail'])
            ? '?detail=' . (int)$_GET['detail']
            : '')
    );
}

$detail = null;

if (isset($_GET['detail'])) {

    $id = (int)$_GET['detail'];

    $s = $koneksi->prepare(
        'SELECT o.*,u.nama,u.email
         FROM orders o
         JOIN users u ON u.id=o.user_id
         WHERE o.id=?'
    );

    $s->bind_param('i', $id);
    $s->execute();

    $detail = $s->get_result()->fetch_assoc();
}

if ($detail):

?>

    <p class="eyebrow">
        DETAIL PESANAN
    </p>

    <h1>
        <?= e($detail['nomor_pesanan']) ?>
    </h1>

    <section class="panel">

        <p>
            <b><?= e($detail['nama_penerima']) ?></b>
            —
            <?= e($detail['email']) ?>

            <br>

            <?= e($detail['nomor_telepon']) ?>

            <br>

            <?= nl2br(e($detail['alamat'])) ?>
        </p>

        <h3>Bukti Pembayaran</h3>
        <?php if ($detail['metode_pembayaran'] === 'COD'): ?>
            <p>Pesanan COD — bukti pembayaran tidak diperlukan.</p>
        <?php elseif ($detail['bukti_pembayaran']): ?>
            <a class="button small" href="<?= base_url($detail['bukti_pembayaran']) ?>" target="_blank">Buka Bukti Pembayaran</a>
            <p><img src="<?= base_url($detail['bukti_pembayaran']) ?>" alt="Bukti pembayaran" style="max-width:320px;max-height:420px;border-radius:10px;border:1px solid #ddd"></p>
        <?php else: ?>
            <p>Customer belum mengunggah bukti pembayaran.</p>
        <?php endif ?>

        <?php

        $s = $koneksi->prepare(
            'SELECT d.*,b.judul
             FROM order_details d
             JOIN books b ON b.id=d.book_id
             WHERE d.order_id=?'
        );

        $s->bind_param(
            'i',
            $detail['id']
        );

        $s->execute();

        $d = $s->get_result();

        ?>

        <table>

            <tr>
                <th>Buku</th>
                <th>Qty</th>
                <th>Harga</th>
                <th>Subtotal</th>
            </tr>

            <?php while ($x = $d->fetch_assoc()): ?>

                <tr>

                    <td>
                        <?= e($x['judul']) ?>
                    </td>

                    <td>
                        <?= $x['quantity'] ?>
                    </td>

                    <td>
                        <?= rupiah($x['harga']) ?>
                    </td>

                    <td>
                        <?= rupiah($x['subtotal']) ?>
                    </td>

                </tr>

            <?php endwhile ?>

        </table>

        <p>
            <b>
                Total: <?= rupiah($detail['total']) ?>
            </b>

            ·

            <?= e($detail['metode_pembayaran']) ?>
        </p>

        <form
            method="post"
            class="row"
        >

            <input
                type="hidden"
                name="id"
                value="<?= $detail['id'] ?>"
            >

            <select name="status_pembayaran">

                <?php foreach (
                    [
                        'Belum Dibayar',
                        'Menunggu Konfirmasi',
                        'Lunas',
                        'Gagal'
                    ] as $v
                ): ?>

                    <option
                        <?= $detail['status_pembayaran'] === $v
                            ? 'selected'
                            : '' ?>
                    >
                        <?= $v ?>
                    </option>

                <?php endforeach ?>

            </select>

            <select name="status_pesanan">

                <?php foreach (
                    [
                        'Menunggu Pembayaran',
                        'Diproses',
                        'Dikemas',
                        'Dikirim',
                        'Selesai',
                        'Dibatalkan'
                    ] as $v
                ): ?>

                    <option
                        <?= $detail['status_pesanan'] === $v
                            ? 'selected'
                            : '' ?>
                    >
                        <?= $v ?>
                    </option>

                <?php endforeach ?>

            </select>

            <button class="button">
                Simpan Status
            </button>

        </form>

    </section>

<?php else: ?>

    <p class="eyebrow">
        TRANSAKSI TOKO
    </p>

    <h1>
        Data Pesanan
    </h1>

    <section class="panel">

        <table>

            <tr>
                <th>ID Pesanan</th>
                <th>User</th>
                <th>Tanggal</th>
                <th>Total</th>
                <th>Metode</th>
                <th>Pembayaran</th>
                <th>Pesanan</th>
                <th></th>
            </tr>

            <?php

            $r = $koneksi->query(
                'SELECT o.*,u.nama
                 FROM orders o
                 JOIN users u ON u.id=o.user_id
                 ORDER BY o.id DESC'
            );

            while ($o = $r->fetch_assoc()):

            ?>

                <tr>

                    <td>
                        <?= e($o['nomor_pesanan']) ?>
                    </td>

                    <td>
                        <?= e($o['nama']) ?>
                    </td>

                    <td>
                        <?= e($o['tanggal_pesanan']) ?>
                    </td>

                    <td>
                        <?= rupiah($o['total']) ?>
                    </td>

                    <td>
                        <?= e($o['metode_pembayaran']) ?>
                    </td>

                    <td>
                        <?= e($o['status_pembayaran']) ?>
                    </td>

                    <td>
                        <?= e($o['status_pesanan']) ?>
                    </td>

                    <td>

                        <a
                            class="button small"
                            href="?detail=<?= $o['id'] ?>"
                        >
                            Detail
                        </a>

                    </td>

                </tr>

            <?php endwhile ?>

        </table>

    </section>

<?php endif; ?>

<?php require __DIR__ . '/footer.php'; ?>

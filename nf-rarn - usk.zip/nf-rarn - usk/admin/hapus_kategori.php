<?php header('Location: kategori.php?hapus='.(int)($_GET['id']??0)); exit;

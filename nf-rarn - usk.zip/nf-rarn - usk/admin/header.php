<?php

require_once __DIR__ . '/../config/koneksi.php';
require_admin();

?>
<!doctype html>
<html lang="id">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width,initial-scale=1"
    >

    <title><?= e($title ?? 'Admin') . ' — NF Rarn' ?></title>

    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Playfair+Display:wght@600;700&display=swap"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="<?= base_url('assets/css/style.css') ?>"
    >

</head>

<body>

    <div class="admin">

        <aside class="side">

            <a
                class="brand"
                href="index.php"
            >
                NF <i>Rarn</i>
            </a>

            <small>ADMIN PANEL</small>

            <a href="index.php">
                Dashboard
            </a>

            <a href="kategori.php">
                Kategori
            </a>

            <a href="buku.php">
                Data Buku
            </a>

            <a href="users.php">
                Data User
            </a>

            <a href="pesanan.php">
                Pesanan
            </a>

            <a href="pesan.php">
                Pesan
            </a>

            <a
                href="<?= base_url() ?>"
                target="_blank"
            >
                Lihat Website ↗
            </a>

            <a href="<?= base_url('auth/logout.php') ?>">
                Logout
            </a>

        </aside>

        <main class="admin-main">

            <?php if ($m = flash('success')): ?>

                <div class="notice success">
                    <?= e($m) ?>
                </div>

            <?php endif ?>

            <?php if ($m = flash('error')): ?>

                <div class="notice error">
                    <?= e($m) ?>
                </div>

            <?php endif ?>
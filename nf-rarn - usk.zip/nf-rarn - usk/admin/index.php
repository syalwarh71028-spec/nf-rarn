<?php

$title = 'Dashboard';
require __DIR__ . '/header.php';

$counts = [];

foreach (
    [
        'books' => 'Total Buku',
        'categories' => 'Total Kategori',
        'users' => 'Total User',
        'orders' => 'Total Pesanan'
    ] as $t => $l
) {
    $r = $koneksi->query("SELECT COUNT(*) n FROM $t");
    $counts[$l] = $r->fetch_assoc()['n'];
}

$income = $koneksi->query(
    "SELECT COALESCE(SUM(total),0)n FROM orders WHERE status_pembayaran='Lunas'"
)->fetch_assoc()['n'];

?>

<p class="eyebrow">RINGKASAN TOKO</p>

<h1>Dashboard</h1>

<div class="stats">

    <?php foreach ($counts as $l => $n): ?>

        <div class="stat">

            <small>
                <?= $l ?>
            </small>

            <strong>
                <?= $n ?>
            </strong>

        </div>

    <?php endforeach ?>

    <div class="stat">

        <small>
            Total Pendapatan
        </small>

        <strong>
            <?= rupiah($income) ?>
        </strong>

    </div>

</div>

<section
    class="panel"
    style="margin-top:25px"
>

    <h2>Pesanan Terbaru</h2>

    <?php

    $orders = $koneksi->query(
        'SELECT nomor_pesanan,total,status_pesanan,tanggal_pesanan
         FROM orders
         ORDER BY id DESC
         LIMIT 6'
    );

    ?>

    <table>

        <tr>
            <th>Pesanan</th>
            <th>Tanggal</th>
            <th>Total</th>
            <th>Status</th>
        </tr>

        <?php while ($o = $orders->fetch_assoc()): ?>

            <tr>

                <td>
                    <?= e($o['nomor_pesanan']) ?>
                </td>

                <td>
                    <?= e($o['tanggal_pesanan']) ?>
                </td>

                <td>
                    <?= rupiah($o['total']) ?>
                </td>

                <td>
                    <?= e($o['status_pesanan']) ?>
                </td>

            </tr>

        <?php endwhile ?>

    </table>

</section>

<?php require __DIR__ . '/footer.php'; ?>
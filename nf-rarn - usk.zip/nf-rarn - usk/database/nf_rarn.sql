-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2026 at 05:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nf_rarn`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `penulis` varchar(150) NOT NULL,
  `penerbit` varchar(150) NOT NULL,
  `tahun_terbit` year(4) NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `deskripsi` text NOT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `rating` decimal(2,1) NOT NULL DEFAULT 4.5,
  `badge` varchar(30) DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `category_id`, `judul`, `penulis`, `penerbit`, `tahun_terbit`, `harga`, `stok`, `deskripsi`, `cover`, `rating`, `badge`, `status`) VALUES
(2, 1, 'Laut Bercerita', 'Leila S. Chudori', 'KPG', '2017', 108000.00, 15, 'Cerita keluarga dan aktivisme yang mengharukan.', 'uploads/buku/buku_e8e65438e34e344d08e1.jpg', 4.9, 'Best Seller', 'aktif'),
(3, 6, 'Atelier of Witch Hat 06', 'Kamome Shirahama', 'Elex Media Komputindo', '2014', 45000.00, 25, 'Manga fantasi tentang Coco yang memasuki dunia sihir dan belajar menjadi penyihir sambil mengungkap rahasia masa lalu.', 'uploads/buku/buku_c27fb59ae2033cca366c.jpg', 4.7, 'Best Seller', 'aktif'),
(4, 4, 'Pembelajaran Mendalam: Pemahaman Praktis dan Implementasinya di Sekolah', 'Yadi Mulyadi, Ph.D.', 'Gramedia', '2009', 89100.00, 18, 'Panduan praktis bagi pendidik untuk memahami dan menerapkan pembelajaran mendalam di lingkungan sekolah.', 'uploads/buku/buku_0a58b8d67bef46b8cb61.png', 4.6, '', 'aktif'),
(5, 3, 'Konsep Pengembangan Diri', 'Abdurrahman Syarif', 'Gramedia', '2018', 89000.00, 22, 'Buku pengembangan diri yang membahas kesabaran, syukur, keikhlasan, tawakal, dan introspeksi dengan pendekatan spiritual.', 'uploads/buku/buku_386e753f4a8030d15d82.png', 4.8, 'Best Seller', 'aktif'),
(6, 3, 'Atomic Habits', 'James Clear', 'Avery', '2018', 135000.00, 15, 'Perubahan kecil untuk hasil luar biasa.', 'uploads/buku/buku_1a84764fe4812adf5c3d.jpg', 4.9, 'Best Seller', 'aktif'),
(7, 3, 'The Psychology of Money', 'Morgan Housel', 'Harriman House', '2020', 125000.00, 17, 'Pelajaran abadi mengenai perilaku manusia dan uang.', 'uploads/buku/buku_453ad9f0e8f16ed3d2bc.jpg', 4.7, 'New', 'aktif'),
(8, 4, 'Laskar Pelangi', 'Andrea Hirata', 'Bentang', '2005', 89000.00, 19, 'Perjuangan anak-anak Belitung meraih pendidikan.', 'uploads/buku/buku_fee84250fe0482ffc671.jpg', 4.8, 'Best Seller', 'aktif'),
(9, 1, 'Perahu Kertas', 'Dee Lestari', 'NF Rarn Press', '2023', 80000.00, 13, 'Buku pilihan kategori Novel.', 'uploads/buku/buku_41a4f8c36945976860f5.jpg', 4.3, 'Best Seller', 'aktif'),
(15, 1, 'Sang Eksekutor', 'Tere Liye', 'Sabak Grip Nusantara', '2026', 110000.00, 17, 'Di sebuah negeri, penegakan hukum kacau balau.\r\nPada yang kecil hukum sangat bengis, pada yang kuat hukum bisa diatur semaunya. Maka seorang eksekutor datang menghabisi petinggi negeri. Mulai dari menteri, jenderal polisi, jaksa, hakim, pengacara, dibunuh satu per satu.', 'uploads/buku/buku_6cd9739611b0af7bb907.jpg', 4.9, 'Best Seller', 'aktif'),
(16, 1, 'Vermilion Rain', 'Kai Elian', 'Gramedia Pustaka Utama', '2023', 85000.00, 20, 'Hujan telah turun selama sembilan puluh hari tanpa henti di Desa Bokudi yang terletak di lereng Gunung Morui. Asayana Brahma, ahli meteorologi yang telah beralih profesi menjadi disaster hunter, mendapat kabar tentang fenomena alam tidak biasa itu dari sahabatnya Elang Langit, seorang pakar klimatologi. Elang khawatir jika hujan itu tidak berhenti, maka lereng gunung akan longsor dan mengubur seluruh desa. Terdorong niat untuk menyelamatkan nyawa, Asa berangkat ke desa itu bersama Elang.', 'uploads/buku/buku_498c3e5678fbb69a6ac1.jpg', 4.0, 'Best Seller', 'aktif'),
(17, 1, 'The Escape Room', 'L D Smithson', 'm&c!', '2025', 120000.00, 21, 'Delapan orang yang tak saling mengenal tiba di benteng laut terpencil di lepas pantai Inggris. Mereka diundang untuk mengikuti The Fortress, acara realitas televisi yang mengharuskan para pesertanya memecahkan serangkaian teka-teki rumit. Namun, ini bukan sekadar permainan—taruhannya jauh lebih mematikan daripada yang mereka bayangkan.\r\nTidak ada yang bisa pergi.', 'uploads/buku/buku_84b013428a071b822e7c.jpg', 4.1, 'Best Seller', 'aktif'),
(18, 1, 'Pasien', 'Naomi Midori', 'Haru', '2026', 75000.00, 22, 'Enam anggota keluarga pemilik toko bangunan ditemukan terbantai di rumah mereka.\r\nPenyelidikan polisi menyimpulkan bahwa mereka saling membunuh karena perebutan warisan.\r\nNamun, bagaimana jika insiden tersebut adalah hasil campur tangan orang lain?', 'uploads/buku/buku_f459d0bc381545a2f2bb.jpg', 4.2, 'New', 'aktif'),
(26, 1, 'Not Quite Dead Yet', 'Holly Jackson', 'Noura Books', '2025', 165000.00, 30, 'Jet sangat membenci Halloween Fair, terutama ketika hidupnya sedang tidak baik-baik saja dan dia tidak ingin bertemu siapa-siapa. Sayangnya, Jet tidak bisa mangkir karena itu adalah acara tahunan yang diselenggarakan keluarganya dan dihadiri seluruh penduduk kota.', 'uploads/buku/buku_905326ffcd7e12f68f99.png', 4.0, 'New', 'aktif'),
(27, 2, 'Akasha: Fire Punch 01', 'Tatsuki Fujimoto', 'Elex Media Komputindo', '2021', 55000.00, 11, 'Manga fantasi gelap karya Tatsuki Fujimoto tentang dunia yang membeku dan perjuangan manusia untuk bertahan hidup.', 'uploads/buku/buku_41cf404dd6348d5d2625.jpg', 4.1, 'Best Seller', 'aktif'),
(30, 1, 'Pingkan Matindas', 'Sania Rasyid', 'Narasi', '2026', 115000.00, 14, 'Sulawesi Utara, Abad ke-17. Jauh sebelum bayang-bayang kompeni menjamah Nusantara, tanah Minahasa adalah palagan bagi keserakahan dan penaklukan tanpa henti. Di tengah kekacauan antar-suku yang brutal, sepasang kekasih berdiri teguh menantang arus zaman.', 'uploads/buku/buku_8688cfcb67386ae0a9d6.png', 4.4, 'New', 'aktif'),
(34, 2, 'Omen', 'Lexie Xu', 'Gramedia Pustaka Utama', '2023', 45000.00, 18, 'Erika mulai meragukan diri sendiri. Apakah sebenarnya dia memang psikopat yang tega mencelakai adik kembarnya sendiri? Apakah selama ini Eliza yang sungguhan anak baik dan dialah si penjahat? Apakah dia memang pantas dijuluki Omen?', 'uploads/buku/buku_b31c0fe91dc280885daf.png', 4.8, 'Best Seller', 'aktif'),
(39, 2, 'Ichi the Witch 01', 'Osamu Nishi, Shiro Usazaki', 'Elex Media Komputindo', '2025', 39998.00, 23, 'Di dunia ini, majik itu makhluk hidup. Lalu, para pemburu yang melewati tes sulit untuk menguasai majik disebut sebagai \"penyihir\". Suatu hari, di sebuah pedalaman gunung terpencil, Raja Majik yang menakutkan bertarung sengit melawan penyihir terkuat. Hingga kemudian, tiba-tiba muncul seorang pemuda yang mengganggu jalannya pertarungan. Pemuda itu bernama Ichi. Pemuda pemburu yang tinggal di gunung dan tidak tahu apa-apa tentang penyihir maupun majik, akan menjadi sosok yang tidak biasa bagi dunia ini! Inilah awal dari kisah fantasi perburuan majik!', 'uploads/buku/buku_829e1a812ccf98f096f7.jpg', 4.3, 'Best Seller', 'aktif'),
(40, 2, 'Light Novel Goblin Slayer 1', 'Kumo Kagyu', 'Phoenix Gramedia Indonesia', '2024', 135000.00, 24, 'Seorang gadis pendeta yang baru saja bergabung dalam sebuah party mendapati dirinya dalam bahaya. Ia diselamatkan oleh seorang pria berzirah besi yang dipanggil Goblin Slayer, yang tanpa ragu menggunakan segala cara dan mengerahkan seluruh tenaganya hanya untuk membasmi goblin.', 'uploads/buku/buku_115b76a010ff4acd7a77.jpg', 4.4, 'Best Seller', 'aktif'),
(42, 2, 'The Eminence in Shadow 1', 'Daisuke Aizawa', 'Phoenix Gramedia Indonesia', '2024', 45000.00, 26, 'Cid Kagenou memiliki mimpi yang berbeda dengan protagonis biasa. Ia bertekad untuk menjadi seorang mastermind yang bergerak diam-diam dari balik layar. Kini ia telah terlahir kembali di dunia berbeda, dan ia akan bekerja keras untuk mewujudkan impiannya tersebut.', 'uploads/buku/buku_531f9534acfbea1eb99b.jpg', 4.6, 'Best Seller', 'aktif'),
(43, 2, 'Tokyo Aliens 01', 'Naoe', 'Elex Media Komputindo', '2020', 150000.00, 26, 'Akira Gunji, seorang anak SMA biasa yang bercita-cita menjadi polisi demi mengikuti jejak mendiang ayahnya. Hidupnya berubah drastis setelah ia tidak sengaja terlibat dalam perseteruan di kereta dan diculik oleh seorang nenek yang ternyata merupakan alien bertentakel.', 'uploads/buku/buku_7328a15e5d6d6e141bb3.jpg', 4.7, 'Best Seller', 'aktif'),
(44, 2, 'Jujutsu Kaisen 09', 'Gege Akutami', 'Elex Media Komputindo', '2023', 45000.00, 28, 'Misi Gojo dan Geto untuk melindungi “wadah plasma bintang” berubah menjadi buruk saat seorang “pembunuh shaman” yang mengaku bernama Fushiguro menyerang mereka secara tiba-tiba. Apa hasil akhir dari kejadian di masa lalu tersebut, yang membuat Gojo menjadi yang terkuat dan membuat Geto memberontak!?', 'uploads/buku/buku_0ab631658a0852d75983.jpg', 4.8, '', 'aktif'),
(45, 2, 'Spy x Family 01', 'Endo Tatsuya', 'Elex Media Komputindo', '2020', 160000.00, 29, 'Spy X Family mengisahkan tentang seorang mata-mata yang demi melancarkan misi perdamaian harus membangun sebuah keluarga palsu. Master mata-mata Twilight tidak tertandingi dalam hal menyamar dalam misi berbahaya demi kemajuan dunia. Agen dengan sebutan nama “Twilight” atau “Senja”, yang merupakan mata-mata utama di Westalia Intelligence Services’ Eastern (W.I.S.E), hidup dengan kerap kali berganti-ganti identitas. Tugasnya itulah yang membuatnya harus melakukan berbagai kehidupan yang berbeda lewat berbagai penyamaran. Walaupun begitu, ia mendedikasikan hidupnya demi kedamaian dunia.', 'uploads/buku/buku_fed36f91ab71a0fd5313.jpg', 4.9, '', 'aktif'),
(53, 3, 'Untukmu yang Sedang Berduka, If You\'re Grieving', 'Jacqueline Whitney', 'Renebook', '2026', 115000.00, 20, 'Buku If You’re Grieving karya Jacqueline Whitney hadir sebagai teman yang lembut bagi siapa pun yang sedang menghadapi kehilangan. Melalui puisi-puisi singkat dan refleksi yang hangat, buku ini mengingatkan bahwa tidak ada kata-kata yang benar-benar mampu menghapus rasa sakit dari duka, tetapi setiap orang yang berduka layak untuk dilihat, didengar, dan dicintai.', 'uploads/buku/buku_600043a230b2e748c1b9.jpg', 4.0, 'New', 'aktif'),
(54, 3, 'From Zero to Survive', 'Theo Derick', 'Elex Media Komputindo', '2025', 120000.00, 21, 'Buku ini adalah rangkuman perjalanan (bertahan dan berkembang) hidup seseorang yang gak punya silver spoon di tangannya (privilege), yang menjalani tantangan hidup sejak hari pertama lahir ke dunia, sampai perlahan menemukan perspektif baru untuk melihat segala hal yang terjadi di dalam hari-harinya, bahkan merasakan “kelegaan dan penerimaan hidup” yang kini membawanya lebih melesat sekaligus lebih merunduk.', 'uploads/buku/buku_f098a1705c4490cc8106.png', 4.1, 'Best Seller', 'aktif'),
(55, 3, 'Laki-Laki dan Isi Kepalanya', 'Muhammad Sahal Al-Bakasy', 'Yash Media', '2022', 125000.00, 22, 'Dunia sering kali menuntut laki-laki untuk menjadi pilar yang tak tergoyahkan. Sejak kecil, mereka diajari untuk menahan tangis, menyembunyikan lelah, dan tetap gagah meski dunia sedang tidak ramah.', 'uploads/buku/buku_ebc9dfd8bee8aded4aff.png', 4.2, 'New', 'aktif'),
(56, 3, 'The Catalyst', 'Jonah Berger', 'Gramedia Pustaka Utama', '2020', 130000.00, 23, 'Saya bersyukur menjadi salah satu dari banyak orang yang belajar dari guru besar ini.\" -Jim Collins, penulis Good to Great Setiap orang memiliki sesuatu yang ingin mereka ubah. Pemasar ingin mengubah pikiran pelanggan dan pemimpin ingin mengubah organisasi. Perusahaan rintisan ingin mengubah industri dan organisasi nirlaba ingin mengubah dunia. Namun, perubahan itu sulit. Sering kali, kita membujuk dan menekan dan mendorong, tetapi tidak ada yang bergerak.', 'uploads/buku/buku_9d745152bfe711ce4883.jpg', 4.3, '', 'aktif'),
(72, 4, 'Satset TKA SK/MAK 2026/2027', 'The King', 'C Media', '2026', 120000.00, 21, 'Menghadapi Tes Kemampuan Akademik (TKA) tidak cukup hanya dengan belajar keras, kamu butuh belajar cerdas. Buku SATSET TKA SMK/MAK hadir sebagai kompas utama bagi siswa SMK/MAK kelas XII untuk menaklukkan ujian masuk perguruan tinggi atau evaluasi akhir dengan hasil maksimal.', 'uploads/buku/buku_d4bfe9f82a78d7c425f8.png', 4.1, 'New', 'aktif'),
(76, 4, 'Statistika untuk Penelitian', 'Dr. Sumanto, MA', 'Andi', '2024', 90000.00, 25, 'Statistika untuk Penelitian : Ilmu Sosial, Pendidikan, Psikologi, Keperawatan, Humaniora, Bisnis dan Manajemen', 'uploads/buku/buku_8c857022bdb7b75e94d0.png', 4.5, '', 'aktif'),
(77, 4, 'Internet of Things Konsep', 'Agus Mulyana', 'Informatika', '2024', 105000.00, 26, 'Buku Fundamental IoT: Konsep, Teknologi dan Aplikasi akan membahas mengenai sejarah dan perkembangan IoT serta beberapa contoh aplikasi dalam kehidupan sehari-hari. Sebelum membahas skema pengiriman data ke cloud atau menerima data dari cloud, buku ini membahas juga beberapa materi bidang embedded system yang sering digunakan.', 'uploads/buku/buku_fb09caa7c59a2407c4cb.png', 4.6, '', 'aktif'),
(78, 4, 'Scalper Mind', 'Andrian F', 'Yash Media', '2026', 90000.00, 27, 'SCALPER MIND hadir bukan untuk menjanjikan kekayaan instan, melainkan untuk melatih Anda menguasai seni trading tercepat dan paling disiplin: Scalping. Buku ini membedah cara berpikir seorang scalper profesional dalam menghadapi ketidakpastian pasar.', 'uploads/buku/buku_8ade69f55802ceed5bb6.png', 4.7, '', 'aktif'),
(85, 5, 'To Be Loved is to Be Known', 'Ody', 'Akad', '2022', 115000.00, 14, 'Seiring dengan berjalannya waktu, Kalila Gemini Jemima dan Ethaniel Vanjiro turut tumbuh semakin dewasa. Memasuki dunia kerja membuat sepasang kekasih itu mulai memiliki kesibukan masing-masing. Ethan dan Kalila kerap ribut kecil karena saling mendamba perhatian dan waktu satu sama lain.', 'uploads/buku/buku_fbb7d56f14dc4f238692.png', 4.4, 'New', 'aktif'),
(89, 5, 'When the Sky is Blooming', 'Ilana Tan', 'Gramedia Pustaka Utama', '2024', 105000.00, 18, 'Mendadak digosipkan berpacaran dengan aktor idola yang sedang populer? Mendadak dicap sebagai aktris picisan tidak tahu diri yang hanya ingin terkenal? Memang merepotkan, tetapi bukan masalah yang terlalu besar. So-ra masih bisa menghadapinya sendiri. Ada satu masalah lain yang lebih membutuhkan perhatian, yaitu masalah menyangkut kemunculan seorang pria dari masa lalu So-ra yang sudah dilupakannya sama sekali.', 'uploads/buku/buku_6dbaaa18a60e693c75db.png', 4.8, 'Best Seller', 'aktif'),
(91, 5, '23:59', 'Brian Khrisna', 'Gramedia Widiasarana Indonesia', '2025', 74998.00, 20, 'Ami akhirnya bertunangan. Ia tersenyum di pelaminan, mengenakan kebaya putih, memamerkan cincin, dan dikelilingi teman-teman serta keluarga yang turut bahagia. Tapi, ada satu hal yang tidak hadir di hari besarnya: kebebasan dari masa lalunya.', 'uploads/buku/buku_ef7797883296e1bc4507.png', 4.0, 'Best Seller', 'aktif'),
(92, 5, 'Satine', 'Ika Natassa', 'Gramedia Pustaka Utama', '2023', 750000.00, 21, '“I just need a proper date.” “Saya cuma butuh teman bicara.” Ada yang bilang hidup yang tertata sempurna ibarat makanan yang dikemas rapi. Semuanya tersusun pada tempatnya, cantik. Lalu, tanpa disangka terjadilah satu peristiwa, kemasan itu tersenggol, dan isinya berserakan di lantai. Hidup yang selama ini dikenal Satine runtuh saat ia menyadari dirinya tidak lebih dari sekadar perempuan kesepian.', 'uploads/buku/buku_0e352245a33601e2f722.png', 4.1, 'Best Seller', 'aktif'),
(93, 5, '3726 MDPL', 'Nurwina Sari', 'Romancious', '2024', 85000.00, 22, 'Selain disibukkan dengan skripsi, Rangga, Ketua Panitia OSPEK Fakultas Kehutanan 2023 itu juga menyibukkan dirinya dengan mengagumi Andini. Seorang mahasiswi yang bercita-cita bisa mendaki Gunung Rinjani, sekaligus adik tingkat yang ia sebut sebagai manusia favorit.', 'uploads/buku/buku_623e9c9eb172d3b0c6d1.png', 4.2, 'Best Seller', 'aktif'),
(106, 5, 'Not a Bed of Roses', 'Wulanfadi None', 'Elex Media Komputindo', '2026', 115000.00, 16, 'Pada pagi hari di tahun baru, Sherly meninggalkan Ilham, membuat kehidupannya juga hilang begitu saja bersama koper merah yang dibawa perempuan itu pergi bersamanya. Ilham tidak bisa menerima perpisahan tiba-tiba tersebut. Karena setelah tiga tahun bersama, satu-satunya dunia Ilham adalah Sherly, sekalipun ada mimpi yang harus ia kubur demi tetap bersama kekasihnya. Namun, keputusan Sherly sudah bulat. Hingga satu kejadian memaksa keduanya membongkar ulang apa makna cinta yang sebenarnya. Makna yang lebih dari sekadar taburan kelopak bunga mawar di tempat tidur pada saat malam pengantin.', 'uploads/buku/buku_36f4b7aae6096a8a52b3.png', 4.6, 'New', 'aktif'),
(107, 6, 'Harry Potter and The Prisoner of Azkaban', 'J.K. Rowling', 'Gramedia Pustaka Utama', '2017', 100000.00, 17, 'Novel Harry Potter dan Tawanan Azkaban merupakan terjemahan Bahasa Indonesia dari novel Harry Potter and The Prisoner of Azkaban, novel ketiga seri Harry Potter yang ditulis oleh J.K. Rowling. Novel ini mengisahkan tentang Harry yang berusaha menghindari Sirius Black, penyihir jahat yang baru kabur dari penjara Azkaban.', 'uploads/buku/buku_08bfcebfce2c8814b994.jpg', 4.7, 'Best Seller', 'aktif'),
(108, 6, 'A Deadly Education (The Scholomance #1)', 'Naomi Novik', 'Elex Media Komputindo', '2025', 105000.00, 18, 'Scholomance bukan sekadar sekolah sihir—tempat itu adalah labirin kematian yang menelan siapa pun yang lengah. Tidak ada guru atau aturan yang jelas, hanya insting, sihir, dan keberuntungan yang menentukan siapa yang masih hidup sampai akhir tahun pelajaran. Galadriel “El” Higgins sudah terbiasa dicurigai. Kekuatannya besar, gelap, dan mudah disalahpahami. Dia berusaha menjaga jarak dari semua orang, karena di Scholomance, memiliki sekutu sama berbahayanya dengan memiliki musuh.', 'uploads/buku/buku_9a8cbfb6d02bfbddafc5.jpg', 4.8, 'New', 'aktif'),
(109, 6, 'Surealis Bawah Sadar', 'Lukita Lova', 'Buku Abdi', '2026', 80000.00, 17, 'Di usia delapan tahun, kemampuan motorik Zidni hilang sehingga dia harus menginap di rumah sakit sebelas hari lamanya. Di dalam mimpi buruknya, ada seorang wanita yang ingin merenggut hidupnya. Di dunia nyata, dia bertemu entitas tak kasatmata lain seorang lelaki berseragam SMA yang mampu menyusup ke dalam mimpi dan mengganti mimpi buruk dengan mimpi indah.', 'uploads/buku/buku_a391c7e8162add58aab3.png', 4.9, 'New', 'aktif'),
(110, 6, 'Archibald: The Star, The Fire & The Shadow', 'Deby Deyn', 'Fantasious', '2026', 115000.00, 20, 'Di balik Perjanjian Crux yang menjaga keseimbangan dunia, empat prefektur sesungguhnya dikendalikan oleh segelintir elite penguasa: Timur dengan api, Utara dengan udara, Barat dengan air, dan Selatan dengan tanah.', 'uploads/buku/buku_4cac1cec5d07f6de232a.png', 4.0, 'New', 'aktif'),
(111, 6, 'The Little Prince', 'Antoine de Saint-Exupery', 'Gramedia Pustaka Utama', '2025', 70000.00, 21, 'Ketika terdampar di Gurun Sahara karena pesawatnya rusak, seorang pilot bertemu dengan seorang anak berambut keemasan yang tersenyum manis. Anak itu meminta digambarkan seekor domba. Apa yang bisa dilakukan sang pilot dalam situasi ajaib ini? Ia pun menggambar domba! Dan dimulailah kisah menakjubkan tentang anak laki-laki dari Asteroid B-612 yang mengarungi jagat raya demi memahami dunia.', 'uploads/buku/buku_78a1d91715c85be895a7.jpg', 4.1, '', 'aktif'),
(113, 6, 'Solo Leveling 4', 'Dubu/Chugong', 'm&c!', '2023', 130000.00, 23, 'Seong Jin-woo, hunter terlemah di level E, mendapat kesempatan dari sistem rahasia yang membuatnya bisa meningkatkan levelnya. Pada awalnya, peningkatan levelnya ini masih ia rahasiakan sampai kemudian Jin-woo memutuskan untuk menguji ulang kemampuannya. Di pengujian ulang ini, ternyata Seong Jin-woo telah menjadi seorang hunter level S, level tertinggi di kalangan para hunter.', 'uploads/buku/buku_adbae205729486d4a554.jpg', 4.3, 'Best Seller', 'aktif'),
(121, 7, 'The Silent Patient', 'Alex Michaelides', 'Gramedia', '2021', 468900.00, 11, 'Thriller psikologis tentang seorang terapis yang mencoba mengungkap alasan seorang pelukis berhenti berbicara setelah tragedi.', 'uploads/buku/buku_074ae8c7ffc131b38cdd.jpg', 4.1, 'Best Seller', 'aktif'),
(122, 7, 'Hunter with a Scalpel', 'Choi Yi-do', 'Elex Media Komputindo', '2022', 115000.00, 12, 'Seorang perempuan ditemukan tewas dengan tubuh yang dijahit menggunakan benang jahit biasa. Si Penjahit, begitu mereka menyebut si pelaku kejahatan. Bagi polisi, itu hanyalah petunjuk. Bagi Seo Se-hyun, dokter forensik jenius yang dikenal karena ketelitian dan instingnya, jahitan itu adalah mimpi buruk yang seharusnya telah terkubur bersama masa lalunya. Saat korban-korban baru berjatuhan dengan pola yang sama, penyelidikan berubah menjadi perlombaan melawan waktu. Detektif Jung Jung-hyun berusaha memburu pelaku, sementara Se-hyun diam-diam mengejar seseorang yang tak boleh ditemukan lebih dulu oleh siapa pun.', 'uploads/buku/buku_9d79973708e46521e8b9.png', 4.2, 'Best Seller', 'aktif'),
(128, 7, 'Chronicle of a Death Foretold', 'Gabriel Garcia Marquez', 'Gramedia Pustaka Utama', '2024', 55000.00, 18, 'Seorang pria pulang ke kota asalnya untuk mengulik pembunuhan yang terjadi lama berselang. Dua puluh tujuh tahun silam, Bayardo San Roman mengembalikan istrinya yang cantik, Angela Vicario, kepada mertuanya, hanya beberapa jam setelah menikah, dengan alasan si istri tidak perawan. Pedro dan Pablo Vicario, kakak kembar Angela, lantas pergi mencari Santiago Nasar, kekasih Angela yang dituding sebagai biang keladi permasalahan ini.', 'uploads/buku/buku_4256feee5a9ec5bf6333.png', 4.8, '', 'aktif'),
(129, 7, 'The Running Grave', 'Robert Galbraith', 'Gramedia Pustaka Utama', '2025', 295000.00, 19, 'Cormoran Strike dihubungi oleh seorang ayah yang mencemaskan anak lelakinya, Will, yang kabur dan bergabung dengan sekte religius di pedalaman Norfolk. Di permukaan, Gereja Humanitarian Universal tampak seperti organisasi damai yang berkampanye untuk dunia yang lebih baik. Meski demikian, Strike mendapati di balik itu tersirat sesuatu yang kejam dan mengancam, juga kematian-kematian yang tak tercatat dan tak dapat dijelaskan.', 'uploads/buku/buku_2448be8a542abffa4c99.jpg', 4.9, '', 'aktif'),
(130, 7, 'Midnight Memories', 'Holipehh', 'Skuad', '2025', 75000.00, 20, 'Sebagai adik kembar Juna, Caramel Qalistya, tidak percaya kakaknya memutuskan mengakhiri hidupnya, Ketika keluarganya memilih pindah ke Bandung, Caramel masuk ke sekolah yang sama dengan Juna. Dia kemudian bertekad menguak misterí kematían Juna yang janggal.', 'uploads/buku/buku_21f6d41a6c3659dffd88.png', 4.0, '', 'aktif'),
(131, 7, 'Kasus-Kasus 7 Sayap Pendosa', 'Jienara', 'Akad', '2025', 67000.00, 21, 'Dalam sebuah perjalanan, para anggota 7 Sayap Pendosa yang dibentuk oleh sekumpulan anak SMA penyuka misteri, Ilham, Harsa, Zidan, dan empat temannya, sepakat untuk menceritakan kisah-kisah misterius yang pernah mereka alami. Serangkaian kisah yang menegangkan ini butuh bantuan kalian untuk membantu memecahkan masalah yang mereka hadapi.', 'uploads/buku/buku_c88c528e0794fb06537d.png', 4.1, '', 'aktif'),
(132, 7, 'Lost LibrThe ary', 'Rebecca Steed dan Wendy Mass', 'Gramedia Pustaka Utama', '2024', 125000.00, 22, 'Suatu hari, perpustakaan kecil gratis muncul di Kota Martinville. Di dekatnya ada plang bertuliskan: AMBIL BUKU, TINGGALKAN BUKU. ATAU DUA-DUANYA! Evan mengambil dua buku dan mendapati buku-buku di perpustakaan tersebut berasal dari Perpustakaan Martinville yang terbakar dua puluh tahun lalu.', 'uploads/buku/buku_139211b8b2a49eaabb47.png', 4.2, 'Best Seller', 'aktif'),
(133, 7, 'Keajaiban Toko Kelontong Namiya', 'Keigo Higashino', 'Gramedia Pustaka Utama', '2020', 120000.00, 23, 'Ketika tiga pemuda berandal bersembunyi di toko kelontong tak berpenghuni setelah melakukan pencurian, sepucuk surat misterius mendadak diselipkan ke dalam toko melalui lubang surat. Surat yang berisi permintaan saran. Sungguh aneh. Namun, surat aneh itu ternyata membawa mereka dalam petualangan melintasi waktu, menggantikan peran kakek pemilik toko kelontong yang menghabiskan tahun-tahun terakhirnya memberikan nasihat tulus kepada orang-orang yang meminta bantuan. Hanya untuk satu malam. Dan saat fajar menjelang, hidup ketiga sahabat itu tidak akan pernah sama lagi', 'uploads/buku/buku_df6cf22341b8b31eb5df.jpg', 4.3, '', 'aktif'),
(140, 7, 'Membunuh Alice', 'Yasumi Kobayashi', 'Gramedia Pustaka Utama', '2026', 165000.00, 30, 'Akhir-akhir ini, Kurisugawa Ari sering dihantui mimpi tentang Alice di Negeri Ajaib. Ketika ia bermimpi tentang Humpty Dumpty yang tercerai-berai di tanah setelah terjatuh dari tembok, seorang peneliti yang dijuluki si Telur di kampusnya jatuh dari atap gedung dan tewas seketika. Ketika ia bermimpi tentang Gryphon yang mati tersedak tiram mentah, seorang dosen di kampusnya juga tewas saat makan tiram.', 'uploads/buku/buku_59091996181e33b34a63.png', 4.0, 'New', 'aktif'),
(141, 8, 'The Odyssey', 'Homer', 'Gramedia', '2021', 100000.00, 11, 'Epos klasik tentang perjalanan panjang Odysseus pulang ke Ithaca setelah Perang Troya, menghadapi monster dan para dewa.', 'uploads/buku/buku_b34c865f7f06d1b5004d.jpg', 4.1, 'Best Seller', 'aktif'),
(142, 8, 'Seporsi Mie Ayam Sebelum Mati', 'Brian Khrisna', 'Gramedia Widiasarana Indonesia', '2025', 75000.00, 12, 'Aku takut kalau ternyata selama ini aku tidak pernah berhasil menjalani hidup seperti sebagaimana seharusnya. Di kepalaku sekarang, pertanyaan ini semakin lama semakin membesar. “Pantaskah hidup ini kulanjutkan?”', 'uploads/buku/buku_f9c0c6d6fe588d6f2d76.jpg', 4.2, 'Best Seller', 'aktif'),
(143, 8, 'Tales of the Birds', 'W. Warde Fowler', 'Gramedia Pustaka Utama', '2026', 80000.00, 13, 'Buku ini berisi kumpulan cerita tentang kehidupan burung-burung yang berlangsung hari demi hari di sekitar rumah, kebun, dan hamparan ladang. Burung gereja berebut tempat bersarang, kawanan gagak berkumpul dalam pertemuan yang khidmat, burung layang-layang yang setia mengikuti musim, dan burung thrush yang memenuhi pagi yang hening dengan nyanyian. Setiap cerita menuturkan petualangan tak terduga, perselisihan kecil, dan kesetiaan; setiap musim menghadirkan drama baru dalam kepak sayap dan lintasan terbang, dan makhluk-makhluk bersayap ini terasa seperti tetangga kita dengan kisah mereka sendiri.', 'uploads/buku/buku_ddaf4f41979be3692e3e.png', 4.3, 'Best Seller', 'aktif'),
(144, 8, 'A Man Called Ove', 'Fredrik Backman', 'Gramedia Pustaka Utama', '2022', 49970.00, 14, 'Seorang penggerutu, kaku, punya rutinitas yang tak bisa diganggu gugat, sumbu pendek pula. Itulah Ove. Orang-orang menyebutnya tetangga pemarah dari neraka. Tapi apa betul Ove pemarah, hanya karena dia tidak terus-menerus memasang senyuman di wajahnya? Di balik tampak luarnya yang pemarah ada cerita dan kepedihan. Keadaan mulai berubah ketika ada pasangan muda cerewet, dengan dua putri cilik bawel, pindah ke sebelah rumahnya dan tak sengaja meremukkan kotak surat Ove. Maka dimulailah rangkaian kejadian yang berujung pada persahabatan, kucing, dan tolong-menolong yang kelak begitu banyak mengubah Ove serta orang-orang di lingkungan tempat tinggalnya.', 'uploads/buku/buku_9585c20fa5e9bfa2567a.jpg', 4.4, 'Best Seller', 'aktif'),
(145, 8, 'Nadira', 'Leila S. Chudori', 'Kepustakaan Populer Gramedia', '2017', 70000.00, 15, 'DI SEBUAH pagi yang murung, Nadira Suwandi menemukan ibunya tewas bunuh diri. Kematian sang ibu, Kemala Yunus, seorang perempuan yang dikenal sangat ekspresif, berpikiran bebas, dan selalu bertarung mencari diri itu, sungguh mengejutkan.', 'uploads/buku/buku_4ac05cf37620a8b15d2d.png', 4.5, '', 'aktif'),
(146, 8, 'Home Sweet Loan', 'Almira Bastari', 'Gramedia Pustaka Utama', '2022', 75000.00, 16, 'Empat orang yang berteman sejak SMA bekerja di perusahaan yang sama meski beda nasib. Di usia 31 tahun, mereka berburu rumah idaman yang minimal nyerempet Jakarta. Kaluna, pegawai Bagian Umum, yang gajinya tak pernah menyentuh dua digit. Gadis ini bekerja sampingan sebagai model bibir, bermimpi membeli rumah demi keluar dari situasi tiga kepala keluarga yang bertumpuk di bawah satu atap. Di tengah perjuangannya menabung, Kaluna dirongrong oleh kekasihnya untuk pesta pernikahan mewah.', 'uploads/buku/buku_dc8c7e5a011aaad5d79e.jpg', 4.6, 'Best Seller', 'aktif'),
(147, 8, 'The Overqualified Leftover Club', 'Margareta Astaman', 'Kompas', '2021', 100000.00, 17, 'Di usia akhir ketika menjelang tiga puluhan, empat perempuan single berjuang untuk mengganti status KTP mereka menjadi \"kawin\". Sang entrepreneur Joana Rompies, postdoctoral candidate Dr. Jessica Winoto, Bu Dosen Chairunnisa Chalid, dan Mbak PNS cum influencer mukbang Hanum Ikkhlasia adalah mereka yang mengemban cap sebagai \"perawan tua\" yang \"pemilih\", \"kepinteran\", dan \"terlalu mandiri\". Bersama, mereka berupaya menjawab definisi \"settling down\" sambil sesekali melemparkan kritik untuk tuntutan keluarga, stereotip gender, dan stigma masyarakat lewat cara-cara yang mereka kenal: menertawakan diri sendiri, menganggap biasa hal yang absurd, dan tentunya, online dating apps!', 'uploads/buku/buku_c11307a4c45a06828930.jpg', 4.7, '', 'aktif'),
(148, 8, 'Teka Teki Rumah Aneh', 'Uketsu', 'Gramedia Pustaka Utama', '2023', 105000.00, 18, 'Seorang kenalan ingin membeli rumah seken di Tokyo dan memperlihatkan denah rumahnya padaku karena merasa ada yang ganjil. Sekilas, rumah ini kelihatan seperti rumah-rumah lain pada umumnya dengan interior yang luas dan terang. Namun, ketika mencermatinya baik-baik, aku mendapati bahwa memang ada keanehan di sana-sini. Keanehan demi keanehan itu bertumpuk, kemudian terjalin membentuk satu “kenyataan”. Kenyataan yang teramat sangat mengerikan, dan sama sekali tidak ingin kupercaya.', 'uploads/buku/buku_ee6c302d523f6991dbaa.jpg', 4.8, 'New', 'aktif'),
(149, 8, 'Funiculi Funicula', 'Toshikazu Kawaguchi', 'Gramedia Pustaka Utama', '2021', 60000.00, 15, 'Buku pilihan kategori Bestseller.', 'uploads/buku/buku_918150f45141ffcfb94f.png', 4.9, '', 'aktif'),
(150, 8, 'Sang Alkemis', 'Paulo Coelho', 'Gramedia Pustaka Utama', '2021', 65000.00, 20, 'Kisah yang sangat sederhana, namun menyimpan kebijaksanaan penuh makna, tentang anak gembala bernama Santiago yang berkelana dari rumahnya di Spanyol ke padang pasir Mesir untuk mencari harta karun terpendam di Piramida-Piramida.', 'uploads/buku/buku_d63e13d883f0ec0ce11b.png', 4.0, 'Best Seller', 'aktif'),
(151, 8, 'Animal Farm', 'George Orwell', 'Sigma', '2025', 70000.00, 21, 'Buku pilihan kategori Bestseller.', 'uploads/buku/buku_2113bc6b767b9a8409cd.jpg', 4.1, '', 'aktif'),
(152, 8, 'The Let Them Theory', 'Mel Robbins', 'Gramedia Pustaka Utama', '2025', 125000.00, 22, 'Let Them Dua Kata Sederhana yang Akan Mengubah Cara Anda Berpikir tentang Seluruh Hidup Anda\r\n.', 'uploads/buku/buku_803fe06608fcf693d5b8.jpg', 4.2, 'Best Seller', 'aktif'),
(153, 8, 'Tentang Suatu Tempat di Wilayah Kinki', 'Sesuji', 'Phoenix Gramedia Indonesia', '2025', 130000.00, 23, 'Seorang editor majalah okultisme yang hilang secara misterius saat menyelidiki berbagai keanehan yang saling terhubung di wilayah Kinki', 'uploads/buku/buku_1b0562bbd02117327be8.png', 4.3, 'Best Seller', 'aktif'),
(154, 8, 'Dompet Ayah Sepatu Ibu', 'J.S. Khairen', 'Grasindo', '2023', 95000.00, 24, 'Perjuangan keluarga menghadapi kehidupan.', 'uploads/buku/buku_cef3c088ea377de889c8.jpg', 4.4, 'Best Seller', 'aktif'),
(155, 8, 'Setelah Melompat Aku Ingin Hidup', 'Brian Khrisna', 'Gramedia Pustaka Utama', '2024', 90000.00, 24, 'Kisah tentang kehidupan, pilihan, dan kesempatan kedua.', 'uploads/buku/buku_7c38635d9cd092fc25c4.png', 4.5, '', 'aktif'),
(156, 8, 'Toko Manisan Ajaib Amberglow', 'Keiko M', 'Gramedia Pustaka Utama', '2025', 145000.00, 26, 'Toko ajaib dengan manisan penuh rahasia.', 'uploads/buku/buku_697f9cd7c2ecd03b874d.png', 4.6, 'New', 'aktif'),
(157, 8, 'Malice', 'Keigo Higashino', 'Gramedia Pustaka Utama', '2025', 150000.00, 27, 'Misteri pembunuhan dengan banyak teka-teki.', 'uploads/buku/buku_edd87bfa6df2a271c3de.jpg', 4.7, 'Best Seller', 'aktif'),
(158, 8, 'Multiidentitas', 'Zahid Ibrahim', 'Gramedia Pustaka Utama', '2026', 100000.00, 28, 'Kisah tentang identitas dan kehidupan seseorang.', 'uploads/buku/buku_31fa178a0eb5047115da.png', 4.8, 'New', 'aktif'),
(159, 8, 'Naoko', 'Keigo Higashino', 'Gramedia Pustaka Utama', '2026', 105000.00, 0, 'Kisah cinta, kehilangan, keluarga, dan identitas setelah sebuah kecelakaan tragis.', 'uploads/buku/buku_d11b0ba2b5d9197e7b17.png', 4.9, 'New', 'aktif'),
(160, 8, 'Goodbye, Eri', 'Tatsuki Fujimoto', 'Shueisha', '2022', 65000.00, 27, 'Manga emosional tentang seorang remaja, ibunya, film, dan seorang gadis misterius.', 'uploads/buku/buku_5efd647b77f61582b118.jpg', 4.0, 'Best Seller', 'aktif'),
(161, 8, 'The Glory Story of Two Umars', 'Fuad Abdurahman', 'Rene Islam', '2020', 85088.00, 5, 'Umar bin Khattab dan Umar bin Abdul Aziz. Dua sosok ini bukan sekadar pemimpin yang cakap dalam mengelola negara, melainkan teladan hidup bagi semua yang berada di bawah naungan kepemimpinan mereka.', 'uploads/buku/buku_dc757332b93a4e292a42.png', 4.5, '', 'aktif'),
(162, 8, 'How to Kill Your Husband', 'Aghnia Sofyan', 'Kepustakaan Populer Gramedia', '2025', 111000.00, 0, 'Seorang pria tewas karena jatuh dari ketinggian. Petunjuk yang ada mendorong Inspektur Polisi Satu Bonita Gamal untuk mencurigai Serena Natalegawa, istri korban. Namun, penyelidikan menuntun Boni pada rahasia gelap orang-orang terdekat korban yang saling berkelindan.\r\nBenarkah Serena telah membunuh suaminya sendiri? Atau semua ini tak sesederhana yang Boni kira?', 'uploads/buku/buku_27260ebb1b4cdc050f89.png', 4.5, 'Best Seller', 'aktif');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `nama_kategori`) VALUES
(8, 'Bestseller'),
(6, 'Fantasy'),
(2, 'Komik'),
(7, 'Mystery'),
(1, 'Novel'),
(4, 'Pendidikan'),
(3, 'Pengembangan Diri'),
(5, 'Romance');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `pesan` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Baru','Dibaca') NOT NULL DEFAULT 'Baru',
  `balasan_admin` text DEFAULT NULL,
  `tanggal_balasan` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `nama`, `email`, `subject`, `pesan`, `tanggal`, `status`, `balasan_admin`, `tanggal_balasan`) VALUES
(1, 2, 'film', 'film@gmail.com', 'hai', 'halo', '2026-08-21 02:46:39', '', 'hi', '2026-10-03 21:12:24');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nomor_pesanan` varchar(30) NOT NULL,
  `tanggal_pesanan` timestamp NOT NULL DEFAULT current_timestamp(),
  `nama_penerima` varchar(100) NOT NULL,
  `nomor_telepon` varchar(25) NOT NULL,
  `alamat` text NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `ongkir` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `metode_pembayaran` varchar(50) NOT NULL,
  `bukti_pembayaran` varchar(255) DEFAULT NULL,
  `status_pembayaran` enum('Belum Dibayar','Menunggu Konfirmasi','Lunas','Gagal') NOT NULL DEFAULT 'Belum Dibayar',
  `status_pesanan` enum('Menunggu Pembayaran','Diproses','Dikemas','Dikirim','Selesai','Dibatalkan') NOT NULL DEFAULT 'Menunggu Pembayaran'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `nomor_pesanan`, `tanggal_pesanan`, `nama_penerima`, `nomor_telepon`, `alamat`, `subtotal`, `ongkir`, `total`, `metode_pembayaran`, `bukti_pembayaran`, `status_pembayaran`, `status_pesanan`) VALUES
(1, 2, 'NFR-20260820-0001', '2026-08-20 05:40:19', 'film', '081285144957', 'GG Remaja VI', 105000.00, 20000.00, 125000.00, 'GoPay', NULL, 'Lunas', 'Dikirim'),
(2, 2, 'NFR-20260820-0002', '2026-08-20 05:48:49', 'film', '081285144957', 'JL.DI Panjaitan', 60000.00, 20000.00, 80000.00, 'COD', NULL, 'Lunas', 'Selesai'),
(3, 2, 'NFR-20260821-0001', '2026-08-21 03:45:54', 'film', '081285144957', 'GG Remaja 6', 80000.00, 20000.00, 100000.00, 'DANA', NULL, 'Lunas', 'Dikemas'),
(4, 2, 'NFR-20260903-0001', '2026-09-02 23:50:04', 'film', '081285144957', 'kgafdtuwi', 105000.00, 10000.00, 115000.00, 'QRIS', NULL, 'Lunas', 'Diproses'),
(5, 2, 'NFR-20260921-0001', '2026-09-21 02:33:06', 'film', '081285144957', 'jl angan agan', 350000.00, 5000.00, 355000.00, 'Transfer Mandiri', 'uploads/pembayaran/bukti_47e8f1ba8b635a6fb2dfda0d.png', 'Lunas', 'Selesai'),
(6, 2, 'NFR-20261022-0001', '2026-10-22 00:07:37', 'film', '081285144957', 'kjuju', 168000.00, 5000.00, 173000.00, 'Transfer BNI', 'uploads/pembayaran/bukti_b43a4a9fbd8d4a46a7736fdf.jpg', 'Lunas', 'Selesai'),
(7, 2, 'NFR-20261103-0001', '2026-11-03 02:24:18', 'film', '081285144957', 'uhuye', 270000.00, 5000.00, 275000.00, 'Transfer BRI', 'uploads/pembayaran/bukti_afaf2c662f0fa26e7a450f03.jpg', 'Menunggu Konfirmasi', 'Menunggu Pembayaran'),
(8, 2, 'NFR-20261103-0002', '2026-11-03 02:50:43', 'film', '081285144957', 'gg remaja', 2625000.00, 5000.00, 2630000.00, 'Transfer BRI', 'uploads/pembayaran/bukti_1ae6844f3253eb5651b87263.jpg', 'Lunas', 'Dikirim'),
(9, 2, 'NFR-20261103-0003', '2026-11-03 04:04:05', 'film', '081285144957', 'gg remaja', 250000.00, 5000.00, 255000.00, 'Transfer BRI', 'uploads/pembayaran/bukti_6041f5642fa380a179d96a73.jpg', 'Menunggu Konfirmasi', 'Menunggu Pembayaran');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `book_id`, `quantity`, `harga`, `subtotal`) VALUES
(1, 1, 159, 1, 105000.00, 105000.00),
(2, 2, 149, 1, 60000.00, 60000.00),
(3, 3, 109, 1, 80000.00, 80000.00),
(4, 4, 159, 1, 105000.00, 105000.00),
(5, 5, 43, 1, 150000.00, 150000.00),
(6, 5, 155, 1, 90000.00, 90000.00),
(7, 5, 15, 1, 110000.00, 110000.00),
(8, 6, 2, 1, 108000.00, 108000.00),
(9, 6, 149, 1, 60000.00, 60000.00),
(10, 7, 159, 2, 105000.00, 210000.00),
(11, 7, 149, 1, 60000.00, 60000.00),
(12, 8, 159, 25, 105000.00, 2625000.00),
(13, 9, 149, 1, 60000.00, 60000.00),
(14, 9, 109, 1, 80000.00, 80000.00),
(15, 9, 15, 1, 110000.00, 110000.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `tanggal_registrasi` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `username`, `password`, `role`, `tanggal_registrasi`) VALUES
(1, 'Administrator NF Rarn', 'admin@nfrarn.local', 'admin', '$2y$10$w0MIVnT5fTrF0b8mV6SKiOsIOdOwrkskvTcRsbVH0EysMisr5..yG', 'admin', '2026-08-20 02:21:36'),
(2, 'film', 'film@gmail.com', 'film', '$2y$10$IBWNIuL9es2oETxcksl7u.pvCLvCLwPFnR8f/FbaA63lsIf5i681m', 'user', '2026-08-20 05:38:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_cart` (`user_id`,`book_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_kategori` (`nama_kategori`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nomor_pesanan` (`nomor_pesanan`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

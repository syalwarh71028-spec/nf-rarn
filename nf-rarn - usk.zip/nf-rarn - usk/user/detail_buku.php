<?php

require_once __DIR__ . '/../config/koneksi.php';

$id = (int)($_GET['id'] ?? 0);

$s = $koneksi->prepare(
    'SELECT b.*,c.nama_kategori
     FROM books b
     JOIN categories c ON c.id=b.category_id
     WHERE b.id=? AND b.status="aktif"'
);

$s->bind_param(
    'i',
    $id
);

$s->execute();

$b = $s->get_result()->fetch_assoc();

if (!$b) {
    flash(
        'error',
        'Buku tidak ditemukan.'
    );

    go('user/katalog.php');
}

$title = $b['judul'] . ' — NF Rarn';

require __DIR__ . '/../partials/header.php';

?>

<section class="detail">

    <div class="cover">

        <?php if ($b['cover']): ?>

            <img
                src="<?= base_url($b['cover']) ?>"
                alt="<?= e($b['judul']) ?>"
            >

        <?php else: ?>

            <span>
                <?= e($b['judul']) ?>
            </span>

        <?php endif ?>

    </div>

    <div>

        <p class="eyebrow">
            <?= e($b['nama_kategori']) ?>
        </p>

        <h1>
            <?= e($b['judul']) ?>
        </h1>

        <p>
            oleh
            <b><?= e($b['penulis']) ?></b>
            ·
            <?= e($b['penerbit']) ?>
            (<?= e($b['tahun_terbit']) ?>)
        </p>

        <div class="rating">
            ★ <?= number_format($b['rating'], 1) ?> / 5
        </div>

        <h2 class="price">
            <?= rupiah($b['harga']) ?>
        </h2>

        <p>
            <?= nl2br(e($b['deskripsi'])) ?>
        </p>

        <p>
            <b>
                Stok tersedia: <?= e($b['stok']) ?>
            </b>
        </p>

        <form
            method="post"
            action="tambah_cart.php"
            class="row"
        >

            <input
                type="hidden"
                name="book_id"
                value="<?= $b['id'] ?>"
            >

            <input
                class="input qty"
                type="number"
                name="quantity"
                min="1"
                max="<?= $b['stok'] ?>"
                value="1"
            >

            <button
                class="button"
                <?= $b['stok'] < 1 ? 'disabled' : '' ?>
            >
                Tambah ke Keranjang
            </button>

        </form>

    </div>

</section>

<?php require __DIR__ . '/../partials/footer.php'; ?>
<?php
require_once __DIR__ . '/../config/koneksi.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') go('user/katalog.php');

$bookId = (int)($_POST['book_id'] ?? 0);
$quantity = max(1, (int)($_POST['quantity'] ?? 1));
$userId = (int)$_SESSION['user_id'];

$book = $koneksi->prepare("SELECT id, stok FROM books WHERE id=? AND status='aktif'");
$book->bind_param('i', $bookId);
$book->execute();
$dataBook = $book->get_result()->fetch_assoc();
if (!$dataBook || (int)$dataBook['stok'] < 1) {
    flash('error', 'Buku tidak tersedia untuk dipesan.');
    go('user/katalog.php');
}

$check = $koneksi->prepare('SELECT id, quantity FROM cart WHERE user_id=? AND book_id=?');
$check->bind_param('ii', $userId, $bookId);
$check->execute();
$existing = $check->get_result()->fetch_assoc();

if ($existing) {
    $newQuantity = min((int)$dataBook['stok'], (int)$existing['quantity'] + $quantity);
    $update = $koneksi->prepare('UPDATE cart SET quantity=? WHERE id=? AND user_id=?');
    $update->bind_param('iii', $newQuantity, $existing['id'], $userId);
    $update->execute();
} else {
    $quantity = min($quantity, (int)$dataBook['stok']);
    $insert = $koneksi->prepare('INSERT INTO cart(user_id, book_id, quantity) VALUES(?,?,?)');
    $insert->bind_param('iii', $userId, $bookId, $quantity);
    $insert->execute();
}

flash('success', 'Buku berhasil ditambahkan ke keranjang.');
go('user/cart.php');

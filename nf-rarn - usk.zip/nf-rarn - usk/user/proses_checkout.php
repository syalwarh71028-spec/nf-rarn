<?php

require_once __DIR__ . '/../config/koneksi.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    go('user/checkout.php');
}

$nama = trim($_POST['nama'] ?? '');
$tel = trim($_POST['telepon'] ?? '');
$alamat = trim($_POST['alamat'] ?? '');
$metode = trim($_POST['metode'] ?? '');

$allowed = [
    'COD',
    'Transfer BCA',
    'Transfer BRI',
    'Transfer BNI',
    'Transfer Mandiri',
    'DANA',
    'GoPay',
    'OVO',
    'ShopeePay',
    'QRIS'
];

$teleponBersih = preg_replace('/[^0-9]/', '', $tel);

if (mb_strlen($nama) < 2) {
    flash('error', 'Nama penerima minimal 2 karakter.');
    go('user/checkout.php');
}

if (strlen($teleponBersih) < 8 || strlen($teleponBersih) > 15) {
    flash('error', 'Nomor telepon harus berisi 8–15 angka, contoh: 081234567890.');
    go('user/checkout.php');
}

if (mb_strlen($alamat) < 5) {
    flash('error', 'Alamat pengiriman minimal 5 karakter.');
    go('user/checkout.php');
}

if (!in_array($metode, $allowed, true)) {
    flash('error', 'Pilih metode pembayaran terlebih dahulu.');
    go('user/checkout.php');
}

$buktiPath = null;
if ($metode !== 'COD') {
    $file = $_FILES['bukti_pembayaran'] ?? null;
    if (!$file || $file['error'] !== UPLOAD_ERR_OK || $file['size'] > 2 * 1024 * 1024) {
        flash('error', 'Upload bukti pembayaran JPG, PNG, atau WEBP (maksimal 2 MB) untuk metode non-COD.');
        go('user/checkout.php');
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($extensions[$mime])) {
        flash('error', 'Format bukti pembayaran harus JPG, PNG, atau WEBP.');
        go('user/checkout.php');
    }
    $filename = 'bukti_' . bin2hex(random_bytes(12)) . '.' . $extensions[$mime];
    $buktiPath = 'uploads/pembayaran/' . $filename;
}

$uid = $_SESSION['user_id'];

try {

    $koneksi->begin_transaction();

    $s = $koneksi->prepare(
        'SELECT c.book_id,c.quantity,b.judul,b.harga,b.stok
         FROM cart c
         JOIN books b ON b.id=c.book_id
         WHERE c.user_id=? FOR UPDATE'
    );

    $s->bind_param(
        'i',
        $uid
    );

    $s->execute();

    $items = $s->get_result();

    if (!$items->num_rows) {
        throw new Exception('Keranjang kosong.');
    }

    $sub = 0;
    $rows = [];

    while ($x = $items->fetch_assoc()) {

        if ($x['stok'] < $x['quantity']) {
            throw new Exception(
                'Stok ' . $x['judul'] . ' tidak mencukupi.'
            );
        }

        $x['subtotal'] = $x['harga'] * $x['quantity'];
        $sub += $x['subtotal'];
        $rows[] = $x;
    }

    $jumlahBuku = array_sum(array_column($rows, 'quantity'));
    $ship = $jumlahBuku >= 2 ? 5000 : 10000;
    $total = $sub + $ship;

    $date = date('Ymd');
    $prefix = 'NFR-' . $date . '-';

    $r = $koneksi->query(
        "SELECT nomor_pesanan
         FROM orders
         WHERE nomor_pesanan LIKE '" .
        $koneksi->real_escape_string($prefix) .
        "%'
         ORDER BY id DESC
         LIMIT 1
         FOR UPDATE"
    );

    $last = $r->fetch_assoc();

    $n = $last
        ? (int)substr($last['nomor_pesanan'], -4) + 1
        : 1;

    $nomor = $prefix . str_pad(
        (string)$n,
        4,
        '0',
        STR_PAD_LEFT
    );

    $statusPay = $metode === 'COD'
        ? 'Belum Dibayar'
        : 'Menunggu Konfirmasi';

    $statusOrder = $metode === 'COD'
        ? 'Diproses'
        : 'Menunggu Pembayaran';

    if ($buktiPath && !move_uploaded_file($_FILES['bukti_pembayaran']['tmp_name'], dirname(__DIR__) . '/' . $buktiPath)) {
        throw new Exception('Bukti pembayaran gagal diunggah.');
    }

    $s = $koneksi->prepare(
        'INSERT INTO orders(
            user_id,
            nomor_pesanan,
            nama_penerima,
            nomor_telepon,
            alamat,
            subtotal,
            ongkir,
            total,
            metode_pembayaran,
            bukti_pembayaran,
            status_pembayaran,
            status_pesanan
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)'
    );

    $s->bind_param(
        'issssdddssss',
        $uid,
        $nomor,
        $nama,
        $tel,
        $alamat,
        $sub,
        $ship,
        $total,
        $metode,
        $buktiPath,
        $statusPay,
        $statusOrder
    );

    $s->execute();

    $oid = $koneksi->insert_id;

    $detail = $koneksi->prepare(
        'INSERT INTO order_details(
            order_id,
            book_id,
            quantity,
            harga,
            subtotal
        ) VALUES(?,?,?,?,?)'
    );

    $stock = $koneksi->prepare(
        'UPDATE books
         SET stok=stok-?
         WHERE id=? AND stok>=?'
    );

    foreach ($rows as $x) {

        $detail->bind_param(
            'iiidd',
            $oid,
            $x['book_id'],
            $x['quantity'],
            $x['harga'],
            $x['subtotal']
        );

        $detail->execute();

        $stock->bind_param(
            'iii',
            $x['quantity'],
            $x['book_id'],
            $x['quantity']
        );

        $stock->execute();

        if ($stock->affected_rows !== 1) {
            throw new Exception(
                'Stok berubah, silakan ulangi checkout.'
            );
        }
    }

    $s = $koneksi->prepare(
        'DELETE FROM cart WHERE user_id=?'
    );

    $s->bind_param(
        'i',
        $uid
    );

    $s->execute();

    $koneksi->commit();

    flash(
        'success',
        'Pesanan berhasil dibuat.'
    );

    go('user/struk.php?id=' . $oid);

} catch (Throwable $e) {

    $koneksi->rollback();

    flash(
        'error',
        $e->getMessage()
    );

    go('user/checkout.php');
}

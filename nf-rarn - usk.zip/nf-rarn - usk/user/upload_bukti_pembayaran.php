<?php
require_once __DIR__ . '/../config/koneksi.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') go('user/pesanan.php');

$orderId = (int)($_POST['order_id'] ?? 0);
$userId = (int)$_SESSION['user_id'];
$order = $koneksi->prepare('SELECT id, metode_pembayaran, bukti_pembayaran FROM orders WHERE id=? AND user_id=?');
$order->bind_param('ii', $orderId, $userId);
$order->execute();
$data = $order->get_result()->fetch_assoc();

if (!$data || $data['metode_pembayaran'] === 'COD') {
    flash('error', 'Bukti pembayaran tidak diperlukan untuk pesanan COD.');
    go('user/pesanan.php');
}

$file = $_FILES['bukti_pembayaran'] ?? null;
if (!$file || $file['error'] !== UPLOAD_ERR_OK || $file['size'] > 2 * 1024 * 1024) {
    flash('error', 'Pilih gambar bukti pembayaran (JPG, PNG, atau WEBP) maksimal 2 MB.');
    go('user/pesanan.php');
}

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
$extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
if (!isset($extensions[$mime])) {
    flash('error', 'Format bukti pembayaran harus JPG, PNG, atau WEBP.');
    go('user/pesanan.php');
}

$name = 'bukti_' . $orderId . '_' . bin2hex(random_bytes(8)) . '.' . $extensions[$mime];
$relative = 'uploads/pembayaran/' . $name;
$destination = dirname(__DIR__) . '/' . $relative;
if (!move_uploaded_file($file['tmp_name'], $destination)) {
    flash('error', 'Bukti pembayaran gagal diunggah.');
    go('user/pesanan.php');
}

if ($data['bukti_pembayaran'] && str_starts_with($data['bukti_pembayaran'], 'uploads/pembayaran/')) {
    $old = dirname(__DIR__) . '/' . $data['bukti_pembayaran'];
    if (is_file($old)) unlink($old);
}

$update = $koneksi->prepare("UPDATE orders SET bukti_pembayaran=?, status_pembayaran='Menunggu Konfirmasi' WHERE id=? AND user_id=?");
$update->bind_param('sii', $relative, $orderId, $userId);
$update->execute();
flash('success', 'Bukti pembayaran berhasil dikirim. Admin akan memeriksanya.');
go('user/pesanan.php');

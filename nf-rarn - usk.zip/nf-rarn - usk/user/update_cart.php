<?php

require_once __DIR__ . '/../config/koneksi.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    go('user/cart.php');
}

$id = (int)$_POST['id'];

$q = max(
    1,
    (int)$_POST['quantity']
);

$s = $koneksi->prepare(
    'SELECT b.stok
     FROM cart c
     JOIN books b ON b.id=c.book_id
     WHERE c.id=? AND c.user_id=?'
);

$s->bind_param(
    'ii',
    $id,
    $_SESSION['user_id']
);

$s->execute();

$x = $s->get_result()->fetch_assoc();

if ($x) {

    $q = min(
        $q,
        $x['stok']
    );

    $s = $koneksi->prepare(
        'UPDATE cart
         SET quantity=?
         WHERE id=? AND user_id=?'
    );

    $s->bind_param(
        'iii',
        $q,
        $id,
        $_SESSION['user_id']
    );

    $s->execute();
}

flash(
    'success',
    'Keranjang diperbarui.'
);

go('user/cart.php');
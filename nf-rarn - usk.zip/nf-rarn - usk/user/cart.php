<?php

require_once __DIR__ . '/../config/koneksi.php';

require_login();

$title = 'Keranjang — NF Rarn';

require __DIR__ . '/../partials/header.php';

$s = $koneksi->prepare(
    "SELECT cart.*,b.judul,b.harga,b.stok,b.cover
     FROM cart
     JOIN books b ON b.id=cart.book_id
     WHERE cart.user_id=? AND b.status='aktif'"
);

$s->bind_param(
    'i',
    $_SESSION['user_id']
);

$s->execute();

$items = $s->get_result();

$subtotal = 0;

?>

<div class="page-title">

    <p class="eyebrow">
        PILIHAN ANDA
    </p>

    <h1>
        Keranjang Belanja
    </h1>

</div>

<section class="two-col">

    <div class="panel">

        <?php if (!$items->num_rows): ?>

            <p>
                Keranjang Anda masih kosong.

                <a href="katalog.php">
                    <b>Mulai jelajahi buku</b>
                </a>
            </p>

        <?php endif ?>

        <?php while ($i = $items->fetch_assoc()):

            $sub = $i['harga'] * $i['quantity'];
            $subtotal += $sub;

        ?>

            <div class="cart-row">

                <?php if ($i['cover']): ?>

                    <img
                        src="<?= base_url($i['cover']) ?>"
                        alt=""
                    >

                <?php else: ?>

                    <div class="cart-placeholder">
                        NF Rarn
                    </div>

                <?php endif ?>

                <div class="grow">

                    <b>
                        <?= e($i['judul']) ?>
                    </b>

                    <p>
                        <?= rupiah($i['harga']) ?>
                        · stok <?= e($i['stok']) ?>
                    </p>

                    <form
                        action="update_cart.php"
                        method="post"
                        class="row"
                    >

                        <input
                            type="hidden"
                            name="id"
                            value="<?= $i['id'] ?>"
                        >

                        <input
                            class="input qty"
                            name="quantity"
                            type="number"
                            min="1"
                            max="<?= $i['stok'] ?>"
                            value="<?= $i['quantity'] ?>"
                        >

                        <button class="button small">
                            Update
                        </button>

                        <a
                            class="button small ghost"
                            href="hapus_cart.php?id=<?= $i['id'] ?>"
                            onclick="return confirm('Hapus buku ini?')"
                        >
                            Hapus
                        </a>

                    </form>

                </div>

                <b>
                    <?= rupiah($sub) ?>
                </b>

            </div>

        <?php endwhile ?>

    </div>

    <aside class="panel summary">

        <h2>
            Ringkasan
        </h2>

        <p>
            <span>Subtotal</span>
            <b><?= rupiah($subtotal) ?></b>
        </p>

        <p>
            <span>Ongkir</span>
            <span>Dihitung saat checkout</span>
        </p>

        <p class="total">
            <span>Total</span>
            <b><?= rupiah($subtotal) ?></b>
        </p>

        <?php if ($subtotal): ?>

            <a
                class="button"
                href="checkout.php"
            >
                Lanjut Checkout
            </a>

        <?php endif ?>

    </aside>

</section>

<?php require __DIR__ . '/../partials/footer.php'; ?>
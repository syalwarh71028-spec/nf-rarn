<?php

require_once __DIR__ . '/../config/koneksi.php';

$title = 'Contact — NF Rarn';
ensure_message_reply_columns();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama = trim($_POST['nama'] ?? '');
    $email = filter_var(
        $_POST['email'] ?? '',
        FILTER_VALIDATE_EMAIL
    );
    $sub = trim($_POST['subject'] ?? '');
    $msg = trim($_POST['pesan'] ?? '');

    if (!$nama || !$email || !$sub || !$msg) {

        flash(
            'error',
            'Semua data pesan wajib diisi.'
        );

    } else {

        $uid = $_SESSION['user_id'] ?? null;

        $s = $koneksi->prepare(
            'INSERT INTO messages(user_id,nama,email,subject,pesan)
             VALUES(?,?,?,?,?)'
        );

        $s->bind_param(
            'issss',
            $uid,
            $nama,
            $email,
            $sub,
            $msg
        );

        $s->execute();

        flash(
            'success',
            'Pesan Anda sudah dikirim ke admin.'
        );
    }

    go('user/contact.php');
}

require __DIR__ . '/../partials/header.php';

$me = user();

?>

<section class="auth panel">

    <p class="eyebrow">
        HUBUNGI KAMI
    </p>

    <h1>
        Contact Admin
    </h1>

    <p>
        Kami akan dengan senang hati membantu Anda.
    </p>

    <form method="post">

        <div class="form-group">

            <label>
                Nama
            </label>

            <input
                class="input"
                name="nama"
                value="<?= e($me['nama'] ?? '') ?>"
                required
            >

        </div>

        <div class="form-group">

            <label>
                Email
            </label>

            <input
                class="input"
                type="email"
                name="email"
                value="<?= e($me['email'] ?? '') ?>"
                required
            >

        </div>

        <div class="form-group">

            <label>
                Subject
            </label>

            <input
                class="input"
                name="subject"
                required
            >

        </div>

        <div class="form-group">

            <label>
                Pesan
            </label>

            <textarea
                name="pesan"
                rows="5"
                required
            ></textarea>

        </div>

        <button class="button">
            Kirim Pesan
        </button>

    </form>

</section>

<?php if ($me): ?>
    <?php
    $history = $koneksi->prepare(
        'SELECT subject, pesan, tanggal, balasan_admin, tanggal_balasan
         FROM messages WHERE user_id=? ORDER BY id DESC'
    );
    $history->bind_param('i', $me['id']);
    $history->execute();
    $messages = $history->get_result();
    ?>
    <section class="panel">
        <p class="eyebrow">RIWAYAT PESAN</p>
        <h2>Pesan dan Balasan Admin</h2>
        <?php if ($messages->num_rows === 0): ?>
            <p>Anda belum memiliki pesan.</p>
        <?php else: ?>
            <?php while ($message = $messages->fetch_assoc()): ?>
                <article class="panel">
                    <h3><?= e($message['subject']) ?></h3>
                    <p><?= nl2br(e($message['pesan'])) ?></p>
                    <small><?= e($message['tanggal']) ?></small>
                    <?php if (!empty($message['balasan_admin'])): ?>
                        <hr>
                        <strong>Balasan Admin</strong>
                        <p><?= nl2br(e($message['balasan_admin'])) ?></p>
                        <small><?= e($message['tanggal_balasan']) ?></small>
                    <?php else: ?>
                        <p><em>Menunggu balasan admin.</em></p>
                    <?php endif; ?>
                </article>
            <?php endwhile; ?>
        <?php endif; ?>
    </section>
<?php else: ?>
    <p>Login untuk melihat riwayat pesan dan balasan admin.</p>
<?php endif; ?>

<?php require __DIR__ . '/../partials/footer.php'; ?>

<?php

require_once __DIR__ . '/../config/koneksi.php';

require_login();

$id = (int)($_GET['id'] ?? 0);

$s = $koneksi->prepare(
    'SELECT o.*,u.nama,u.email
     FROM orders o
     JOIN users u ON u.id=o.user_id
     WHERE o.id=? AND o.user_id=?'
);

$s->bind_param(
    'ii',
    $id,
    $_SESSION['user_id']
);

$s->execute();

$o = $s->get_result()->fetch_assoc();

if (!$o) {

    flash(
        'error',
        'Struk tidak ditemukan.'
    );

    go('user/pesanan.php');
}

$s = $koneksi->prepare(
    'SELECT d.*,b.judul
     FROM order_details d
     JOIN books b ON b.id=d.book_id
     WHERE d.order_id=?'
);

$s->bind_param(
    'i',
    $id
);

$s->execute();

$details = $s->get_result();

$title = 'Struk ' . $o['nomor_pesanan'];

require __DIR__ . '/../partials/header.php';

?>

<div
    class="receipt"
    id="receipt"
>

    <div class="receipt-head">

        <h1>
            NF Rarn
        </h1>

        <b>
            BOOKSTORE
        </b>

        <p>
            STRUK PEMBELIAN
        </p>

    </div>

    <p>

        <b>
            No. Pesanan:
        </b>

        <?= e($o['nomor_pesanan']) ?>

        <br>

        <b>
            Tanggal:
        </b>

        <?= date(
            'd F Y, H:i',
            strtotime($o['tanggal_pesanan'])
        ) ?>

    </p>

    <h3>
        Data Pembeli
    </h3>

    <p>

        <?= e($o['nama_penerima']) ?>

        <br>

        <?= e($o['email']) ?>

        <br>

        <?= e($o['nomor_telepon']) ?>

        <br>

        <?= nl2br(e($o['alamat'])) ?>

    </p>

    <table>

        <thead>

            <tr>

                <th>
                    Buku
                </th>

                <th>
                    Qty
                </th>

                <th>
                    Harga
                </th>

                <th>
                    Subtotal
                </th>

            </tr>

        </thead>

        <tbody>

            <?php while ($d = $details->fetch_assoc()): ?>

                <tr>

                    <td>
                        <?= e($d['judul']) ?>
                    </td>

                    <td>
                        <?= $d['quantity'] ?>
                    </td>

                    <td>
                        <?= rupiah($d['harga']) ?>
                    </td>

                    <td>
                        <?= rupiah($d['subtotal']) ?>
                    </td>

                </tr>

            <?php endwhile ?>

        </tbody>

    </table>

    <p>

        Subtotal:
        <b>
            <?= rupiah($o['subtotal']) ?>
        </b>

        <br>

        Ongkir:
        <b>
            <?= rupiah($o['ongkir']) ?>
        </b>

        <br>

        <b>
            Total: <?= rupiah($o['total']) ?>
        </b>

    </p>

    <p>

        Metode Pembayaran:
        <b>
            <?= e($o['metode_pembayaran']) ?>
        </b>

        <br>

        Status Pembayaran:
        <b>
            <?= e($o['status_pembayaran']) ?>
        </b>

        <br>

        Status Pesanan:
        <b>
            <?= e($o['status_pesanan']) ?>
        </b>

    </p>

    <p>

        <b>
            Terima kasih telah berbelanja di NF Rarn!
        </b>

    </p>

    <div class="actions">

        <button
            class="button"
            onclick="window.print()"
        >
            Cetak Struk
        </button>

        <button
            class="button ghost"
            onclick="window.print()"
        >
            Simpan sebagai PDF
        </button>

        <a
            class="button ghost"
            href="pesanan.php"
        >
            Lihat Pesanan
        </a>

        <a
            class="button ghost"
            href="<?= base_url() ?>"
        >
            Kembali ke Home
        </a>

    </div>

</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
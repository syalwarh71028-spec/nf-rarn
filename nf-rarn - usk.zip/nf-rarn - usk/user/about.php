<?php

require_once __DIR__ . '/../config/koneksi.php';

$title = 'About Us — NF Rarn';

require __DIR__ . '/../partials/header.php';

?>

<section class="detail">

    <div class="cover">

        <span>
            NF Rarn
            <br>
            <br>
            <b>
                Every book
                <br>
                is a doorway.
            </b>
        </span>

    </div>

    <div>

        <p class="eyebrow">
            TENTANG KAMI
        </p>

        <h1>
            Ruang untuk setiap pencinta cerita
        </h1>

        <p>
            NF Rarn hadir sebagai ruang bagi siapa saja
            yang mencintai buku dan cerita. Kami menyediakan
            berbagai pilihan bacaan mulai dari novel, komik,
            pengembangan diri, hingga buku pendidikan dengan
            pengalaman belanja yang mudah dan menyenangkan.
        </p>

        <p>
            Kami percaya sebuah buku yang tepat dapat menjadi
            teman, jendela, maupun awal dari perubahan besar.
        </p>

        <a
            class="button"
            href="katalog.php"
        >
            Temukan Buku Anda
        </a>

    </div>

</section>

<?php require __DIR__ . '/../partials/footer.php'; ?>
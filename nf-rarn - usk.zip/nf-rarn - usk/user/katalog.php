<?php

require_once __DIR__ . '/../config/koneksi.php';

$title = 'Katalog Buku — NF Rarn';

require __DIR__ . '/../partials/header.php';

$keyword = trim($_GET['q'] ?? '');
$cat = (int)($_GET['category'] ?? 0);
$sort = $_GET['sort'] ?? 'newest';

$orders = [
    'cheap' => 'b.harga ASC',
    'expensive' => 'b.harga DESC',
    'rating' => 'b.rating DESC',
    'newest' => 'b.id DESC'
];

$order = $orders[$sort] ?? $orders['newest'];

$sql = "SELECT b.*,c.nama_kategori
        FROM books b
        JOIN categories c ON c.id=b.category_id
        WHERE b.status='aktif'";

$types = '';
$params = [];

if ($keyword !== '') {

    $sql .= ' AND (b.judul LIKE ? OR b.penulis LIKE ?)';

    $like = "%$keyword%";

    $types = 'ss';
    $params = [$like, $like];
}

if ($cat) {

    $sql .= ' AND b.category_id=?';

    $types .= 'i';
    $params[] = $cat;
}

$sql .= " ORDER BY $order";

$s = $koneksi->prepare($sql);

if ($types) {
    $s->bind_param(
        $types,
        ...$params
    );
}

$s->execute();

$books = $s->get_result();

$cats = $koneksi->query(
    'SELECT * FROM categories ORDER BY nama_kategori'
);

?>

<div class="page-title">

    <p class="eyebrow">
        KOLEKSI NF RARN
    </p>

    <h1>
        Katalog Buku
    </h1>

    <p>
        Temukan bacaan yang akan menetap di hati Anda.
    </p>

</div>

<form
    class="filter"
    method="get"
>

    <input
        class="input"
        name="q"
        placeholder="Cari judul atau penulis..."
        value="<?= e($keyword) ?>"
    >

    <select name="category">

        <option value="">
            Semua kategori
        </option>

        <?php while ($c = $cats->fetch_assoc()): ?>

            <option
                value="<?= $c['id'] ?>"
                <?= $cat === $c['id'] ? 'selected' : '' ?>
            >
                <?= e($c['nama_kategori']) ?>
            </option>

        <?php endwhile ?>

    </select>

    <select name="sort">

        <option value="newest">
            Buku terbaru
        </option>

        <option
            value="cheap"
            <?= $sort === 'cheap' ? 'selected' : '' ?>
        >
            Harga termurah
        </option>

        <option
            value="expensive"
            <?= $sort === 'expensive' ? 'selected' : '' ?>
        >
            Harga termahal
        </option>

        <option
            value="rating"
            <?= $sort === 'rating' ? 'selected' : '' ?>
        >
            Rating tertinggi
        </option>

    </select>

    <button class="button small">
        Terapkan
    </button>

</form>

<div
    id="kategori"
    class="book-grid"
>

    <?php if (!$books->num_rows): ?>

        <p>
            Belum ada buku yang sesuai.
        </p>

    <?php endif ?>

    <?php

    while ($b = $books->fetch_assoc()) {
        include __DIR__ . '/../partials/book-card.php';
    }

    ?>

</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
<?php

require_once __DIR__ . '/../config/koneksi.php';

require_login();

$title = 'Pesanan Saya — NF Rarn';

require __DIR__ . '/../partials/header.php';

$s = $koneksi->prepare(
    'SELECT * FROM orders WHERE user_id=? ORDER BY id DESC'
);

$s->bind_param(
    'i',
    $_SESSION['user_id']
);

$s->execute();

$orders = $s->get_result();

?>

<div class="page-title">

    <p class="eyebrow">
        RIWAYAT BELANJA
    </p>

    <h1>
        Pesanan Saya
    </h1>

</div>

<section class="panel">

    <table>

        <thead>

            <tr>

                <th>
                    No. Pesanan
                </th>

                <th>
                    Tanggal
                </th>

                <th>
                    Total
                </th>

                <th>
                    Metode
                </th>

                <th>
                    Pembayaran
                </th>

                <th>
                    Pesanan
                </th>

                <th>Bukti Pembayaran</th>
                <th></th>

            </tr>

        </thead>

        <tbody>

            <?php if (!$orders->num_rows): ?>

                <tr>

                    <td colspan="8">
                        Belum ada pesanan.
                    </td>

                </tr>

            <?php endif ?>

            <?php while ($o = $orders->fetch_assoc()): ?>

                <tr>

                    <td>

                        <?php if ($o['metode_pembayaran'] === 'COD'): ?>
                            <small>COD — tidak perlu bukti</small>
                        <?php elseif ($o['bukti_pembayaran']): ?>
                            <a class="button small ghost" href="<?= base_url($o['bukti_pembayaran']) ?>" target="_blank">Lihat Bukti</a>
                        <?php else: ?>
                            <small>Bukti belum tersedia.</small>
                        <?php endif ?>

                    </td>

                    <td>
                        <?= e($o['nomor_pesanan']) ?>
                    </td>

                    <td>
                        <?= date('d/m/Y', strtotime($o['tanggal_pesanan'])) ?>
                    </td>

                    <td>
                        <?= rupiah($o['total']) ?>
                    </td>

                    <td>
                        <?= e($o['metode_pembayaran']) ?>
                    </td>

                    <td>
                        <?= e($o['status_pembayaran']) ?>
                    </td>

                    <td>
                        <?= e($o['status_pesanan']) ?>
                    </td>

                    <td>

                        <a
                            class="button small"
                            href="struk.php?id=<?= $o['id'] ?>"
                        >
                            Struk
                        </a>

                    </td>

                </tr>

            <?php endwhile ?>

        </tbody>

    </table>

</section>

<?php require __DIR__ . '/../partials/footer.php'; ?>

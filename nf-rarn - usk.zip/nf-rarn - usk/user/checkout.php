<?php

require_once __DIR__ . '/../config/koneksi.php';

require_login();

$title = 'Checkout — NF Rarn';

require __DIR__ . '/../partials/header.php';

$s = $koneksi->prepare(
    'SELECT c.*,b.judul,b.harga
     FROM cart c
     JOIN books b ON b.id=c.book_id
     WHERE c.user_id=? AND b.status="aktif"'
);

$s->bind_param(
    'i',
    $_SESSION['user_id']
);

$s->execute();

$items = $s->get_result();

$subtotal = 0;
$arr = [];

while ($i = $items->fetch_assoc()) {

    $arr[] = $i;
    $subtotal += $i['harga'] * $i['quantity'];
}

if (!$arr) {
    flash(
        'error',
        'Keranjang kosong.'
    );

    go('user/cart.php');
}

$me = user();

$jumlahBuku = array_sum(array_column($arr, 'quantity'));
$ongkir = $jumlahBuku >= 2 ? 5000 : 10000;
$total = $subtotal + $ongkir;

?>

<div class="page-title">

    <p class="eyebrow">
        SATU LANGKAH LAGI
    </p>

    <h1>
        Checkout Pesanan
    </h1>

</div>

<form
    action="proses_checkout.php"
    method="post"
    class="two-col"
    enctype="multipart/form-data"
>

    <div class="panel">

        <h2>
            Data Pembeli
        </h2>

        <div class="form-group">

            <label>
                Nama penerima
            </label>

            <input
                class="input"
                name="nama"
                value="<?= e($me['nama']) ?>"
                required
            >

        </div>

        <div class="form-group">

            <label>
                Email
            </label>

            <input
                class="input"
                value="<?= e($me['email']) ?>"
                disabled
            >

        </div>

        <div class="form-group">

            <label>
                Nomor telepon
            </label>

            <input
                class="input"
                name="telepon"
                required
                inputmode="numeric"
                placeholder="Contoh: 081234567890"
            >

        </div>

        <div class="form-group">

            <label>
                Alamat pengiriman
            </label>

            <textarea
                name="alamat"
                rows="4"
                required
                placeholder="Tulis alamat lengkap pengiriman"
            ></textarea>

        </div>

        <h2>
            Metode Pembayaran
        </h2>

        <div class="form-group">

            <select name="metode" id="metode-pembayaran" required>

                <option value="COD">
                    COD — Bayar langsung kepada kurir
                </option>

                <option value="Transfer BCA">
                    Transfer Bank — BCA 1234567890
                </option>

                <option value="Transfer BRI">
                    Transfer Bank — BRI 1234567890
                </option>

                <option value="Transfer BNI">
                    Transfer Bank — BNI 1234567890
                </option>

                <option value="Transfer Mandiri">
                    Transfer Bank — Mandiri 1234567890
                </option>

                <option value="DANA">
                    E-Wallet — DANA
                </option>

                <option value="GoPay">
                    E-Wallet — GoPay
                </option>

                <option value="OVO">
                    E-Wallet — OVO
                </option>

                <option value="ShopeePay">
                    E-Wallet — ShopeePay
                </option>

                <option value="QRIS">
                    QRIS — Scan di aplikasi pembayaran
                </option>

            </select>

        </div>

        <div class="form-group" id="upload-bukti-wrap" hidden>
            <label>Bukti pembayaran</label>
            <input class="input" type="file" name="bukti_pembayaran" id="bukti-pembayaran" accept="image/jpeg,image/png,image/webp">
            <small>Wajib untuk transfer, e-wallet, dan QRIS. Format JPG/PNG/WEBP, maksimal 2 MB.</small>
        </div>

    </div>

    <aside class="panel summary">

        <h2>
            Detail Pesanan
        </h2>

        <?php foreach ($arr as $i): ?>

            <p>

                <span>
                    <?= e($i['judul']) ?>
                    × <?= $i['quantity'] ?>
                </span>

                <b>
                    <?= rupiah($i['harga'] * $i['quantity']) ?>
                </b>

            </p>

        <?php endforeach ?>

        <p>

            <span>
                Subtotal
            </span>

            <b>
                <?= rupiah($subtotal) ?>
            </b>

        </p>

        <p>

            <span>
                Ongkir
            </span>

            <b>
                <?= rupiah($ongkir) ?>
            </b>

        </p>

        <p class="total">

            <span>
                Total Pembayaran
            </span>

            <b>
                <?= rupiah($total) ?>
            </b>

        </p>

        <button
            class="button"
            type="submit"
        >
            Bayar & Buat Pesanan
        </button>

    </aside>

</form>

<script>
(() => {
    const metode = document.getElementById('metode-pembayaran');
    const wrap = document.getElementById('upload-bukti-wrap');
    const bukti = document.getElementById('bukti-pembayaran');
    const update = () => {
        const perluBukti = metode.value !== 'COD';
        wrap.hidden = !perluBukti;
        bukti.required = perluBukti;
        if (!perluBukti) bukti.value = '';
    };
    metode.addEventListener('change', update);
    update();
})();
</script>

<?php require __DIR__ . '/../partials/footer.php'; ?>

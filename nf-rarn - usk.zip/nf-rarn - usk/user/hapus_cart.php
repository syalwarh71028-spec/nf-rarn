<?php

require_once __DIR__ . '/../config/koneksi.php';

require_login();

$id = (int)($_GET['id'] ?? 0);

$s = $koneksi->prepare(
    'DELETE FROM cart WHERE id=? AND user_id=?'
);

$s->bind_param(
    'ii',
    $id,
    $_SESSION['user_id']
);

$s->execute();

flash(
    'success',
    'Buku dihapus dari keranjang.'
);

go('user/cart.php');
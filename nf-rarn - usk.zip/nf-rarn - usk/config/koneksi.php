<?php

$koneksi = new mysqli(
    'localhost',
    'root',
    '',
    'nf_rarn'
);

if ($koneksi->connect_error) {
    die(
        'Koneksi database gagal: ' .
        htmlspecialchars($koneksi->connect_error)
    );
}

$koneksi->set_charset('utf8mb4');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function base_url(string $path = ''): string
{
    return '/nf-rarn/' . ltrim($path, '/');
}

function e($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function rupiah($nilai): string
{
    return 'Rp ' . number_format(
        (float)$nilai,
        0,
        ',',
        '.'
    );
}

function go(string $path): never
{
    header(
        'Location: ' . base_url($path)
    );

    exit;
}

function flash(
    string $key,
    ?string $value = null
): ?string {

    if ($value !== null) {
        $_SESSION['flash'][$key] = $value;
        return null;
    }

    $v = $_SESSION['flash'][$key] ?? null;

    unset($_SESSION['flash'][$key]);

    return $v;
}

function user(): ?array
{
    global $koneksi;

    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $s = $koneksi->prepare(
        'SELECT id,nama,email,username,role
         FROM users
         WHERE id=?'
    );

    $s->bind_param(
        'i',
        $_SESSION['user_id']
    );

    $s->execute();

    return $s->get_result()->fetch_assoc() ?: null;
}

function ensure_message_reply_columns(): void
{
    global $koneksi;

    foreach ([
        'balasan_admin' => 'TEXT NULL',
        'tanggal_balasan' => 'DATETIME NULL'
    ] as $column => $definition) {
        $escaped = $koneksi->real_escape_string($column);
        $check = $koneksi->query("SHOW COLUMNS FROM messages LIKE '{$escaped}'");
        if ($check && $check->num_rows === 0) {
            $koneksi->query("ALTER TABLE messages ADD COLUMN `{$column}` {$definition}");
        }
    }
}

function require_login(): void
{
    if (!user()) {
        flash(
            'error',
            'Silakan login terlebih dahulu.'
        );

        go('auth/login.php');
    }
}

function require_admin(): void
{
    require_login();

    if (($_SESSION['role'] ?? '') !== 'admin') {
        flash(
            'error',
            'Akses admin ditolak.'
        );

        go('index.php');
    }
}

function cart_count(): int
{
    global $koneksi;

    if (empty($_SESSION['user_id'])) {
        return 0;
    }

    $s = $koneksi->prepare(
        'SELECT COALESCE(SUM(quantity),0) jumlah
         FROM cart
         WHERE user_id=?'
    );

    $s->bind_param(
        'i',
        $_SESSION['user_id']
    );

    $s->execute();

    return (int)$s->get_result()
        ->fetch_assoc()['jumlah'];
}

function upload_cover(
    array $file,
    ?string $old = null
): ?string {

    if (
        ($file['error'] ?? UPLOAD_ERR_NO_FILE)
        === UPLOAD_ERR_NO_FILE
    ) {
        return $old;
    }

    if (
        $file['error'] !== UPLOAD_ERR_OK ||
        $file['size'] > 2 * 1024 * 1024
    ) {
        throw new Exception(
            'Cover maksimal 2 MB.'
        );
    }

    $mime = (
        new finfo(FILEINFO_MIME_TYPE)
    )->file($file['tmp_name']);

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowed[$mime])) {
        throw new Exception(
            'Format cover harus JPG, PNG, atau WEBP.'
        );
    }

    $name =
        'buku_' .
        bin2hex(random_bytes(10)) .
        '.' .
        $allowed[$mime];

    $dir =
        dirname(__DIR__) .
        '/uploads/buku/';

    if (
        !move_uploaded_file(
            $file['tmp_name'],
            $dir . $name
        )
    ) {
        throw new Exception(
            'Cover gagal diunggah.'
        );
    }

    if (
        $old &&
        str_starts_with(
            $old,
            'uploads/buku/'
        ) &&
        is_file(
            dirname(__DIR__) .
            '/' .
            $old
        )
    ) {
        unlink(
            dirname(__DIR__) .
            '/' .
            $old
        );
    }

    return 'uploads/buku/' . $name;
}
